package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.CreateHtmlPageDayCall.DB_H2_FILE;
import static org.fluentcodes.projects.stadtbook.service.DayService.TEMPLATE_DIR;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.files.DirectoryWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.templates.TemplateDirResourceCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.models.DaysOfMonth;

public class CreateCalenderCall extends EventCall {

  public static final String MONTH_DIR = "MonthDir";
  public static final String DATES = "dates";
  public static final String EVENT_COUNT_BY_DATE = "EventCountByDate";
  private String dbHostKey;

  public CreateCalenderCall() {
    super();
    this.dbHostKey = DB_H2_FILE;
  }

  public Object execute(EOInterfaceScalar eo) {
    check();

    while (getCurrentDate().isBefore(getStopDate())) {
      EoRoot eoRoot = readCalenderFromDb();
      persistCalender(eoRoot);
      setCurrentDate(getCurrentDate().plusMonths(1));
    }
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void persistCalender(EoRoot eo) {
    DaysOfMonth daysOfMonth = new DaysOfMonth(getCurrentDate().getYear(), getCurrentDate().getMonth(), (List)eo.get(DATES));
    LocalDate next = getCurrentDate().plusMonths(1);
    LocalDate prev = getCurrentDate().minusMonths(1);
    eo.set(daysOfMonth.toHtml(), "calender");
    eo.set(EventCall.deriveMonthName(prev), "prev");
    eo.set("" + getCurrentDate().getMonth() + " " + getCurrentDate().getYear(), "month");
    eo.set(EventCall.deriveMonthName(next), "next");
    eo.set("M&uuml;nchen", "town");

    String fileNameTemplate = "Calender.tpl";

    TemplateDirResourceCall call = new TemplateDirResourceCall(TEMPLATE_DIR, fileNameTemplate);
    String content = call.execute(eo);

    String fileNameHtml = deriveMonthName(getCurrentDate()) + ".html";
    DirectoryWriteCall writeCall = new DirectoryWriteCall(MONTH_DIR, fileNameHtml);
    writeCall.setContent(content);
    System.out.println(writeCall.execute(eo));
  }

   private EoRoot readCalenderFromDb() {
    LocalDate startTime = LocalDate.of(getCurrentDate().getYear(), getCurrentDate().getMonth(), 1);
    LocalDate monthAfter = getCurrentDate().plusMonths(1);
    LocalDate stopTime = LocalDate.of(monthAfter.getYear(), monthAfter.getMonth(), 1);

    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(startTime);
    conditionList.add(stopTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(dbHostKey, EVENT_COUNT_BY_DATE);
    call.setTargetPath("/(List)" + DATES);
    call.execute(eo);
    return eo;
  }
}
