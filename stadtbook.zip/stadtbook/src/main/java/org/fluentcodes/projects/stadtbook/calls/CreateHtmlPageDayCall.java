package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.files.DirectoryWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.templates.TemplateDirResourceCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreateHtmlPageDayCall extends EventCall {
  Logger LOG = LoggerFactory.getLogger(CreateHtmlPageDayCall.class);
  public static final String TEMPLATE_DIR = "TemplateDir";
  public static final String DAY_TARGET_DIR = "DayTargetDir";
  public static final String TARGET_PATH = "/(List,Event)dates";
  public static final String DB_H2_FILE = "h2:file:basic";

  private String dbHostKey;
  public CreateHtmlPageDayCall() {
    super();
    this.dbHostKey = DB_H2_FILE;
  }

  public Object execute(EOInterfaceScalar eo) {
    check();

    while (getCurrentDate().isBefore(getStopDate())) {
      EoRoot eoRoot = readDayFromDb();
      persistDay(eoRoot);
      setCurrentDate(getCurrentDate().plusDays(1));
    }
    return "";
  }

  public void persistDay(EoRoot eo) {
    eo.set(createMonthNav(), "monthNav");
    Map<String, List<Event>> eventTypeMap = createEventTypeMap(eo);

    eo.set(createHtmlTypeNav(eventTypeMap), "typeNav");
    eo.set(createHtmlTypeEvents(eventTypeMap), "typedEvents");
    eo.set(getCurrentDate().getDayOfMonth() + ". " + getCurrentDate().getMonth().getValue() + ". " + getCurrentDate().getYear(),
        "date");
    eo.set("M&uuml;nchen", "town");
    eo.set("https://www.stadtbook.de/", "url");
    eo.set(getCurrentDay(), "day");
    eo.set(getCurrentMonth(), "month");
    eo.set(getCurrentDate().getYear(), "year");


    String fileNameTemplate = "Day.tpl";
    TemplateDirResourceCall call = new TemplateDirResourceCall(TEMPLATE_DIR, fileNameTemplate);
    String content = call.execute(eo);
    content =  replaceUml(content);
    //String fileNameHtml = "" + getName(getCurrentDate())  + ".html";
    String fileNameHtml = "" +  EventCall.deriveDateName(getCurrentDate()) + ".html";
    DirectoryWriteCall writeCall = new DirectoryWriteCall(DAY_TARGET_DIR, fileNameHtml);
    writeCall.setContent(content);
    LOG.info(writeCall.execute(eo));
  }

  @Override
  public void setByParameter(String values) {

  }

  EoRoot readDayFromDb() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(getCurrentDate());
    conditionList.add(getCurrentDate().plusDays(1));
    eo.set(conditionList, "conditionList");
    DbSqlReadCall call = new DbSqlReadCall(dbHostKey, "EventInDateInterval");
    call.setTargetPath(TARGET_PATH);
    call.getListParams().setRowEnd(10000);
    call.execute(eo);
    return eo;
  }

  private String createHtmlTypeNav(Map<String, List<Event>> eventTypeMap) {
    StringBuilder result = new StringBuilder();
    for (String type: eventTypeMap.keySet()) {
      result.append("<a class=\"type-link\" href=\"#");
      result.append(type);
      result.append("\">");
      result.append(type);
      result.append("</a> - ");
    }
    return result.toString();
  }

  private String createHtmlTypeEvents(Map<String, List<Event>> eventTypeMap) {
    StringBuilder html = new StringBuilder();
    for (Map.Entry<String, List<Event>> eventEntry: eventTypeMap.entrySet()) {
      html.append(createTypeAnchor(eventEntry.getKey()));
      html.append(createHtmlTypeEntries(eventEntry.getKey(), eventEntry.getValue()));
    }
    return html.toString();
  }

  private Map<String, List<Event>> createEventTypeMap(EoRoot eo) {
    Map<String, List<Event>> typeMap = new TreeMap<>();
    List<Event> object = (List<Event>) eo.get("/dates");
    for (Event event : object) {
      String type = event.getType();
      type = Types.getDefault(type);
      if (!typeMap.containsKey(type)) {
        typeMap.put(type, new ArrayList<>());
      }
      typeMap.get(type).add(event);
    }
    return typeMap;
  }

  private String createTypeAnchor(String type) {
      StringBuilder html = new StringBuilder();
    html.append("" +
        "<a name=\"");
    html.append(type);
    html.append("\"></a>");
      html.append("" +
          "\n     <div class=\"type-title\">");

    html.append("" +
        "\n        <div><h3>");
    html.append("<a " +
        " class=\"button button-collapse\"" +
        " id=\"Img-" + type + "\"" );
    html.append(" onmouseover=\"stadtbook.show('");
    html.append(type);
    html.append("')\"");
    html.append(" onmouseout=\"stadtbook.hide('");
    html.append(type);
    html.append("')\"");
    html.append(" onclick=\"stadtbook.flagAndShow('");
    html.append(type);
    html.append("')\">");
    html.append("&#x2795;</a> &nbsp; ");
    html.append(type);
    html.append("" +
        "\n        &nbsp; <span class=\"type-date\">(");
    html.append(getCurrentDate().getDayOfMonth());
    html.append(". ");
    html.append(getCurrentDate().getMonth().getValue());
    html.append(". ");
    html.append(getCurrentDate().getYear());
    html.append(")</span>");
    html.append("</h3>");
    html.append("" +
        "\n        </div>");

    html.append("" +
        "\n        <div class=\"type-up\">");
    html.append("" +
        "\n        <a href=\"#top\" class=\"button button-up\">&#x1F53C;</a>" +
        "\n     </div>\n");
    html.append("</div>\n");
    return html.toString();
  }

  private void addSpecialLinks(final String type, StringBuilder html) {
    if (type.equals("Konzertex")) {
      addSpecialLink("bandsintown", ParserBandsInTownCall.createLink(getCurrentDate()), html);
    }
  }

  private void addSpecialLink(final String view, final String url, StringBuilder html) {
      html.append("" +
          "\n    <div class=\"event\">" +
          "\n       <div></div>" +
          "\n      <div>"+
          "            <a href=\"");

      html.append(   "\" target=\"external\"><h4>");
      html.append(view);
      html.append("</h4>\n" +
          "</a>" +
          "\n          </div>" +
          "\n    </div>");
  }

  private String createHtmlTypeEntries(final String type, List<Event> events) {
    StringBuilder eventsDaily = new StringBuilder();

    eventsDaily.append("" +
          "\n     <div id=\"Events-");
    eventsDaily.append(type);
    eventsDaily.append("\"  onmouseout=\"stadtbook.hide('" + type + "');\" >");
    for (Event event: events) {
      eventsDaily.append("" +
          "\n        <div class=\"Event\" itemscope itemtype=\"http://schema.org/Event\">");
      eventsDaily.append("" +
          "\n           <div></div>");
      eventsDaily.append("" +
          "\n           <div class=\"location\" itemscope itemtype=\"http://schema.org/Location\" itemprop=\"name\" content=\"" + event.getLocation() + "\">");
      eventsDaily.append( event.getLocation());
      eventsDaily.append("</div>" +
          "             <div></div>");
      eventsDaily.append("" +
          "\n           <div class=\"startDate\" itemprop=\"startDate\" content=\"" + event.getStartTime().toString() + "\">");
      eventsDaily.append( getTime(event.getStartTime()));
      eventsDaily.append("</div>");
      eventsDaily.append("" +
          "\n           <h4 itemprop=\"name\" content=\"" + event.getArtistTitle() + "\">");
      eventsDaily.append( event.getArtistTitle());
      if (event.hasArtist()) {
        eventsDaily.append("<span itemprop=\"performer\" content=\"" + event.getArtist() + "\"></span>");
      }
      eventsDaily.append("</h4>");
      eventsDaily.append("" +
          "\n           <div class=\"artist-links\">");

      createSearch(event, eventsDaily);
      eventsDaily.append(" ");

      createInfo(event, eventsDaily);
      eventsDaily.append(" ");

      createYoutube(event.getType(), event.getArtistTitle(), eventsDaily);
      eventsDaily.append(" ");

      eventsDaily.append("</div>");
      eventsDaily.append("" +
          "\n        </div>");
    }
    addSpecialLinks(type, eventsDaily);
    eventsDaily.append("" +
        "\n     </div>\n");
    return eventsDaily.toString();
  }

  void createSearch(Event event, StringBuilder eventsDaily) {
    if (event.hasEventUrl()) {
      return;
    }
    eventsDaily.append("<a href=\"https://duckduckgo.com/?q=" + event.getArtistTitle() + "\" " +
        "target=\"external\"" +
        "class=\"button button-search\">" +
        "&#x1F50E;" +
        "</a>");
  }

  void createInfo(Event event, StringBuilder eventsDaily) {
    if (!event.hasEventUrl()) {
      return;
    }
    eventsDaily.append("<a href=\"" + event.getEventUrl() + "\" " +
        "target=\"external\"" +
        "class=\"button button-info\">" +
        "ℹ️" +
        "</a>");
  }

  void createYoutube(String type, String artistTitle, StringBuilder eventsDaily) {
    if (type==null || !type.matches("(Konzerte|Kabarett)")) {
      return;
    }
      eventsDaily.append("<a href=\"https://www.youtube.com/results?search_query=");
      eventsDaily.append(type);
      eventsDaily.append("+");
      eventsDaily.append(artistTitle);
      eventsDaily.append("\" target=\"external\" " +
          "class=\"button button-video\">" +
          "&#x1F3AC;" +
          "</a>");
  }

  static String getTime(LocalDateTime localDateTime) {
    return "" + localDateTime.getHour() + ":" + getMinute(localDateTime);
  }

  static String getMinute(LocalDateTime localDate) {
    String minute = Integer.valueOf(localDate.getMinute()).toString();
    return minute.length()==1? "0" + minute:minute;
  }

  static String replaceUml(String input) {
    return input
        .replaceAll("ß","&szlig;")
        .replaceAll("Ä","&Auml;")
        .replaceAll("Ü","&Uuml;")
        .replaceAll("Ö","&Ouml;")
        .replaceAll("ö","&ouml;")
        .replaceAll("ä","&auml;")
        .replaceAll("ü","&uuml;");
  }

  private String createMonthNav() {
    StringBuilder calenderNav = new StringBuilder();
    calenderNav.append("         <iframe src=\"months/" + EventCall.deriveMonthName(getCurrentDate()) + ".html?" +
        deriveDateName(getCurrentDate()) + "\"></iframe>\n");
    return calenderNav.toString();
  }

}
