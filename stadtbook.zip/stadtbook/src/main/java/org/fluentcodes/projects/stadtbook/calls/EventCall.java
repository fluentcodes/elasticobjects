package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.CallImpl;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;

public abstract class EventCall extends CallImpl {
  public static final String EVENTS_PARSED_PATH = "/(List,EventParsed)events";
  public static final String EVENTS_PATH = "/(List,Event)events";
  public static final String INPUT_DIR = "InputDir";
  private boolean test;
  private LocalDate currentDate;
  private LocalDate startDate;
  private LocalDate stopDate;
  private String parseType;
  private List<EventParsed> eventParsedList;
  public EventCall() {
    super();
    eventParsedList = new ArrayList<>();
  }

  protected void mapToResult(EOInterfaceScalar eo) {
    eo.set(eventParsedList, getTargetPath());
  }

  EOInterfaceScalar moveToResult(EOInterfaceScalar eo) {
    return eo.getEo( getTargetPath());
  }

  void check() {
    if (!hasStartDate()) {
      throw new EoException("Null startDate");
    }
    if (!hasStopDate()) {
      throw new EoException("Null stopDate");
    }
    if (!hasTargetPath()) {
      setTargetPath(EVENTS_PARSED_PATH);
    }
    currentDate = startDate;
    eventParsedList = new ArrayList<>();
  }


  public String getParseType() {
    return parseType;
  }

  public String fetchParseType() {
    return parseType;
  }

  void setParseType(String parseType) {
    this.parseType = parseType;
  }

  public boolean hasParseType(){
    return parseType!=null && !parseType.isEmpty();
  }

  String getFileName() {
    return fetchParseType() + ":" + deriveDateName(startDate) + "-" + deriveDateName(stopDate);
  }

  public static String deriveDateName(LocalDate startDate) {
    return startDate.getYear() + "-" +
        leadingZero(startDate.getMonth().getValue()) + "-" +
        leadingZero(startDate.getDayOfMonth());
  }

  public static String deriveMonthName(LocalDate startDate) {
    return startDate.getYear() + "-" +
        leadingZero(startDate.getMonth().getValue());
  }

  public String getCurrentMonth() {
    return
        leadingZero(currentDate.getMonth().getValue());
  }
  public String getCurrentDay() {
    return
        leadingZero(currentDate.getDayOfMonth());
  }

  static String leadingZero(Integer integer) {
    return integer>9 ? integer.toString() : "0"+integer;
  }

  public boolean isTest() {
    return test;
  }

  public EventCall setTest(boolean test) {
    this.test = test;
    return this;
  }

  public LocalDate getStartDate() {
    return startDate;
  }

  public EventCall setStartDate(LocalDate startDate) {
    this.startDate = startDate;
    return this;
  }

  public boolean hasStartDate() {
    return startDate!=null;
  }

  public LocalDate getStopDate() {
    return stopDate;
  }

  public EventCall setStopDate(LocalDate stopDate) {
    this.stopDate = stopDate;
    return this;
  }

  public boolean hasStopDate() {
    return stopDate!=null;
  }

  public LocalDate getCurrentDate() {
    return currentDate;
  }

  public void setCurrentDate(LocalDate currentDate) {
    this.currentDate = currentDate;
  }

  public List<EventParsed> getEventParsedList() {
    return eventParsedList;
  }

  public void setEventParsedList(List<EventParsed> eventParsedList) {
    this.eventParsedList = eventParsedList;
  }

  public void addEvent(EventParsed event) {
    eventParsedList.add(event);
  }
}
