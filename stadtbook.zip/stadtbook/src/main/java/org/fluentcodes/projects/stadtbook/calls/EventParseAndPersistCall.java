package org.fluentcodes.projects.stadtbook.calls;

import java.util.List;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxReadCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventParseAndPersistCall extends EventCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventParseAndPersistCall.class);
  public static final String DB_MODELS_H2_FILE = "h2:file";
  public static final String EVENTS = "events";
  private ParserCall parserCall;
  private Boolean persistXlsx = false;
  private Boolean persistDb = false;
  private boolean readXlsx = false;
  public EventParseAndPersistCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    if (parserCall == null) {
      throw new EoException("No parser defined");
    }
    check();
    parserCall.setStartDate(getStartDate());
    parserCall.setStopDate(getStopDate());
    parserCall.setTest(isTest());
    parserCall.setTargetPath(getTargetPath());
    String fileName = parserCall.getFileName() + ".xlsx";

    if (!readXlsx) {
      parserCall.initDriver();
      parserCall.execute(eo);
      EOInterfaceScalar eventsEo = moveToResult(eo);
      if (persistXlsx) {
        XlsxWriteCall writeCall = new XlsxWriteCall(INPUT_DIR, fileName);
        writeCall.getListParams().setRowHead(0);
        writeCall.execute(eventsEo);
        LOGGER.info("Written " + ((EoChild)eo.getEo(EVENTS)).size() + " to " + fileName);
      }
    }
    else {
      XlsxReadCall readCall = new XlsxReadCall(INPUT_DIR, fileName);
      readCall.setTargetPath(getTargetPath());
      readCall.getListParams().setRowHead(0);
      readCall.execute(eo);
      LOGGER.info("Readed " + ((EoChild)eo.getEo(EVENTS)).size() + " from " + fileName);
    }

    if (persistDb) {
      EoRoot eoDb = ObjectProvider.createEoWithClasses(List.class, Event.class);
      List<EventParsed> values = (List<EventParsed>)moveToResult(eo).get();
      int counter = 0;
      for (EventParsed event: values) {
        if (!event.getPersist()) {
          continue;
        }
        event.prepare();
        eoDb.set(event, String.valueOf(counter));
        counter++;
      }


      Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
      //writeCall.setCondition("persist eq true");
      writeCall.execute(eoDb);
      LOGGER.info("Written " + counter + " entries from totally " + ((EoChild)eo.getEo(EVENTS)).size() + " entries to DB");
    }
    return "";
  }

  public ParserCall getParserCall() {
    return parserCall;
  }

  public EventParseAndPersistCall setParserCall(ParserCall parserCall) {
    this.parserCall = parserCall;
    return this;
  }

  public Boolean getPersistXlsx() {
    return persistXlsx;
  }

  public EventParseAndPersistCall setPersistXlsx(Boolean persistXlsx) {
    this.persistXlsx = persistXlsx;
    return this;
  }

  public Boolean getPersistDb() {
    return persistDb;
  }

  public EventParseAndPersistCall setPersistDb(Boolean persistDb) {
    this.persistDb = persistDb;
    return this;
  }

  public boolean isReadXlsx() {
    return readXlsx;
  }

  public EventParseAndPersistCall setReadXlsx(boolean readXlsx) {
    this.readXlsx = readXlsx;
    return this;
  }

  @Override
  public void setByParameter(String values) {

  }

}
