package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties;

public class ParserAllEventsInCall extends ParserCall {
  private final static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.(\\d\\d)\\.(\\d\\d\\d\\d), (\\d\\d):(\\d\\d)");
  private final static Pattern PATTERN_PLZ = Pattern.compile("(.*) (\\d\\d\\d\\d\\d) (.*)");
  private final static String[] TYPES = new String[]{"Konzerte", "Bühne", "Sport", "Freizeit","Weiterbildung","Kinder"};
  private String type = "Event";
  private List<EventParsed> events = new ArrayList<>();

  public ParserAllEventsInCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType() : "AllEventsIn";
  }

  @Override
  public Object execute(EOInterfaceScalar eo) {
    while (getCurrentDate().isBefore(getStopDate())) {
      parse("https://allevents.in/munich/" + getCurrentDate().getYear() + "-" + getCurrentMonth() + "-" + getCurrentDay() + "?ref=whitemenu");
      setCurrentDate(getCurrentDate().plusDays(1));
    }
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }


  private void parse(String url) {
    getDriver().get(url);//toggle__trigger
    List<WebElement> boxElements = getDriver().findElements(new By.ByClassName("meta"));
    for (WebElement boxElement: boxElements) {
      parseElement(boxElement);
    }
    System.out.println("* PARSE " + url);
  }

  private EventParsed parseElement(WebElement element) {
    EventParsed event = new EventParsed();
    event.setSource("allevents");
    event.setType(type);

    return event;
  }

}
