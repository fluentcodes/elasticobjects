package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.MonthEnum;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserBackstageCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserBackstageCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.  (.*) (\\d\\d\\d\\d)");
  private static Pattern PATTERN_TIME = Pattern.compile("(\\d\\d):(\\d\\d) (.*)");
  private static Pattern PATTERN_LOCATION = Pattern.compile("<strong>(BACKSTAGE .*)</strong>");
  private List<LocalDate> localDates = new ArrayList<>();



  public ParserBackstageCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    for (int i=1;i<20;i++) {
      parse("https://backstage.eu/veranstaltungen/live.html?product_list_limit=25&p=" + i);
    }
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("product-item-link"));
    List<String> urls = new ArrayList<>();
    for (int i=0;i<elements.size();i++) {
      String link = elements.get(i).getAttribute("href");
      if (link == null) {
        continue;
      }
      urls.add(link);
      if (isTest()) {
        break;
      }
    }
    for (String detailUrl: urls) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Backstage");
      event.setLocation("Backstage");
      event.setEventUrl(detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, detailUrl);
      addEvent(event);
    }
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Backstage";
  }

  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);

    WebElement titleElement = getDriver().findElement(new By.ByTagName("h1"));
    String artist = titleElement
        .findElement(new By.ByTagName("span"))
        .getText();
    artist = StringUpperFirstCharCall.upperWords(artist);
    if (artist.contains("- Leider")) {
      artist = artist.replaceAll("- Leider.*", "");
      event.setPersist(false);
    }
    event.setArtist(artist);

    // content
    try {
      WebElement descriptionElement = getDriver().findElement(new By.ByClassName("description"));
      try {
        String content = findContent(descriptionElement);
        if (content.length()>500) {
          content = content.substring(0,500);
        }
        event.setContent(content);
      } catch (Exception e) {
        event.setContent(e.getMessage() + descriptionElement.getAttribute("innerHTML"));
        event.setPersist(false);
      }
    }
    catch (Exception e) {
      event.setContent("Could not find description");
      event.setPersist(false);
    }

    // link bandlinksandvideolinks
    List<WebElement> linkElements = getDriver().findElements(new By.ByClassName("bandlinksandvideolinks"));
    for (WebElement linkElement: linkElements) {
      WebElement content = linkElement.findElement(new By.ByTagName("a"));
      String link = content.getAttribute("href");
      if (link == null) {
        continue;
      }
      if (!link.startsWith("https:")) {
        continue;
      }
      if (link.contains("muenchenticket.de") && !link.equals("https://muenchenticket.de/")) {
        event.setSourceTicketUrl(link);
      }
      else if (link.contains("eventim.de") && !link.equals("https://eventim.de/")) {
        event.setSourceTicketUrl(link);
      }
      else {
        if (event.getArtistUrl()!=null) {
          link = link + ", " + event.getArtistUrl();
        }
        event.setArtistUrl(link);
      }
    }
    // date
      WebElement dateElement = getDriver().findElement(new By.ByClassName("tstripe-header"));
    String dateTest = dateElement.getAttribute("innerHTML");
    if (dateTest == null) {
      return;
    }
    try {
      event.setStartTime(parseDate(dateTest));
    }
    catch (Exception e) {
      event.setContent(e.getMessage());
      event.setPersist(false);
    }
    Matcher locationMatcher = PATTERN_LOCATION.matcher(dateTest);
    if (locationMatcher.find()) {
      String location = locationMatcher.group(1);
      event.setLocation(StringUpperFirstCharCall.upperWords(location));
    }

  }

  private String findContent(WebElement element) {
    try {
      WebElement contentElement = element
          .findElement(new By.ByTagName("div"));
      return findContent(contentElement);
    }
    catch (Exception e) {
      return element.getAttribute("innerHTML");
    }

  }

  private LocalDateTime parseDate(String content) {
    int minute=0;
    int hour = 0;
    int year =2022;
    int month = 6;
    int day = 1;
    Matcher dateMatcher = PATTERN_DATE.matcher(content);
    if (dateMatcher.find()) {
      day = Integer.parseInt(dateMatcher.group(1));
      String monthS = dateMatcher.group(2);
      month = MonthEnum.getInt(monthS);
      year = Integer.parseInt(dateMatcher.group(3));
    }
    else {
      return null;
    }
    Matcher timeMatcher = PATTERN_TIME.matcher(content);
    if (timeMatcher.find()) {
      hour= Integer.parseInt(timeMatcher.group(1));
      minute = Integer.parseInt(timeMatcher.group(2));
    }
    return LocalDateTime.of(year, month, day, hour, minute);
  }

}
