package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserBahnwaerterThielCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserBahnwaerterThielCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile(" (\\d\\d)\\.(\\d\\d).(\\d\\d\\d\\d).*(\\d\\d):(\\d\\d)<");

  private static Pattern PATTERN_ARTIST = Pattern.compile("(.*?)<br>(.*)");
  private static Pattern PATTERN_EVENTS = Pattern.compile("\"(https://www.theatron-pfingstfestival.de/portfolio-items/.*?)/\"");

  public ParserBahnwaerterThielCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Bahnwaerterthiel";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parseList("https://www.bahnwaerterthiel.de/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseList(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> eventElements = getDriver().findElements(new By.ByClassName("has-text-align-center"));
    for (WebElement eventElement: eventElements) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Bahnwarter Thiel");
      event.setLocation("Bahnwärter Thiel");
      event.setEventUrl(url);
      event.setType(Types.KONZERTE.getDefault());
      String eventText = eventElement.getAttribute("innerHTML");

      try {
        String title = eventElement.findElement(new By.ByTagName("strong")).getAttribute("innerHTML");
        String content = "";
        Matcher titleMatcher = PATTERN_ARTIST.matcher(title);
        if (titleMatcher.find()) {
          title = titleMatcher.group(1);
          content = titleMatcher.group(2);
        }
        if (title.length() > 99) {
          title = title.substring(0, 99);
        }
        if (content.length() > 499) {
          content = content.substring(0, 499);
        }
        event.setTitle(title);
        event.setArtistTitle(title);
        event.setContent(content);
      }
      catch (Exception e) {
        LOGGER.warn("Could not parse for date: " + eventText);
        continue;
      }


      Matcher datePattern = PATTERN_DATE.matcher(eventText);
      if (datePattern.find()) {
        int day = Integer.parseInt(datePattern.group(1));
        int month = Integer.parseInt(datePattern.group(2));
        int year = Integer.parseInt(datePattern.group(3));
        int hour = Integer.parseInt(datePattern.group(4));
        int min = Integer.parseInt(datePattern.group(5));
        event.setStartTime(LocalDateTime.of(year, month, day, hour, min));
      }
      else {
        LOGGER.warn("Could not parse for date: " + eventText);
      }

      if (event.getTitle().contains("Volkstheater BackstageKlub")) {
        event.setPersist(false);
        event.setType(Types.THEATER.getDefault());
      }
      else if (event.getTitle().contains("Flohmarkt")) {
        event.setType(Types.MAERKTE.getDefault());
      }
      else if (!event.getContent().contains("LIVE")) {

      }
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }
}
