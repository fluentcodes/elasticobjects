package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Locations;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.fluentcodes.projects.stadtbook.parser.MonthConversion;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserBandsInTownCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserBandsInTownCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile(" - (\\d+):(\\d\\d) (AM|PM)");
  private List<LocalDate> localDates = new ArrayList<>();

  public ParserBandsInTownCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"bandsintown";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    while (getCurrentDate().isBefore(getStopDate())) {
      parse(createLink(getCurrentDate()));
      setCurrentDate(getCurrentDate().plusDays(1));
    }
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  public static String createLink(LocalDate currentDate) {
    return "https://www.bandsintown.com/?city_id=2867714&came_from=250&date=" +
        currentDate.getYear() + "-" +
        currentDate + "-" +
        currentDate +
        "T00%3A00%3A00%2C" +
        currentDate.getYear() + "-" +
        currentDate + "-" +
        currentDate +
        "T23%3A59%3A59&date_filter=Today&recommended_artists_filter=All+Artists";
  }

  @Override
  public void setByParameter(String values) {

  }

  private boolean parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> linkElements = getDriver().findElements(new By.ByTagName("a"));
    for (WebElement linkElement: linkElements) {
      String href = linkElement.getAttribute("href");
      if (href==null) {
        continue;
      }
      if (!href.contains("https://www.bandsintown.com/e")) {
        continue;
      }
      EventParsed event = new EventParsed();
      event.setOriginal(false);
      event.setPersist(true);
      event.setSourceEventUrl(href);
      parseElement(linkElement, event);
      String linkHtml = linkElement
          .getAttribute("innerHTML")
          .replaceAll("<", "\n<");
      if (!event.hasStartTime()) {
        LOGGER.info("StartTime could not be derived");
        event.setStartTime(getCurrentDate().atStartOfDay());
        event.setContent(linkHtml);
      }
      if (!event.hasLocation()) {
        LOGGER.info("Location could not be derived");
        event.setContent(linkHtml);
      }
      if (!event.hasArtist()) {
        LOGGER.info("Artist could not be derived");
        event.setContent(linkHtml);
      }
      event.setNaturalId();
      addEvent(event);
    }

    return true;
  }



  private void parseElement(WebElement linkElement, EventParsed event) {
    List<WebElement> divElements = linkElement.findElements(new By.ByTagName("div"));
    for (WebElement divElement:divElements) {
      String classAtt = divElement.getAttribute("class");
      String divHtml = divElement.getAttribute("innerHTML");
      LOGGER.info(divHtml);
      if (classAtt.equals("bqB5zhZmpkzqQcKohzfB")) {
        event.setLocation(divHtml);
      }
      else if (classAtt.equals("_5CQoAbgUFZI3p33kRVk")) {
        event.setArtist(divHtml);
        event.setArtistTitle(divHtml);
      }
      if (classAtt.equals("") && divHtml.contains(" PM")) {
        Matcher dateMatcher = PATTERN_DATE.matcher(divHtml);
        if (dateMatcher.find()) {
          LocalDateTime startTime = getCurrentDate().atStartOfDay();
          int hours = Integer.parseInt(dateMatcher.group(1));
          if (dateMatcher.group(3).equals("PM")) {
            hours = hours + 12;
          }
          int min = Integer.parseInt(dateMatcher.group(2));
          startTime = startTime.plusHours(hours);
          startTime = startTime.plusMinutes(min);
          event.setStartTime(startTime);
        }
      }
    }
  }

}
