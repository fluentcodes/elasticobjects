package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserFeierwerkCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserFeierwerkCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile(" (\\d\\d)\\.(\\d\\d).(\\d\\d\\d\\d)<");
  private static Pattern PATTERN_TIME = Pattern.compile("Einlass: (\\d\\d).(\\d\\d) Uhr");

  private static Pattern PATTERN_SUB_TYPE = Pattern.compile("Stil:</b></span>\\s*(.*)\\s*<span class");
  //VVK: 22,00 Euro
  private List<LocalDate> localDates = new ArrayList<>();



  public ParserFeierwerkCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    Set<String> urls = new LinkedHashSet<>();
    for (int i=0;i<20;i++) {
      parseForUrl("https://www.feierwerk.de/konzert-kulturprogramm/kkp?tx_search_fesearch%5B%40widget_0%5D%5BcurrentPage%5D=" + i +"&cHash=f38a331991f7f97c1f7ca3f9bb273b5b", urls);
      if (isTest()) {
        break;
      }
    }
    for (String url:urls) {
      try {
        parse(url);
      }
      catch (Exception e) {
        LOGGER.warn(e.getMessage());
      }
    }
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseForUrl(String url, Set<String> detailUrls) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);

    List<WebElement> elements = getDriver().findElements(new By.ByClassName("event-linker"));
    for (WebElement element:elements) {
      String elementContent = element.getAttribute("innerHTML");
      String link = element.getAttribute("href");
      if (link == null) {
        continue;
      }
      detailUrls.add(link);
      if (isTest()) {
        break;
      }
    }
  }

  private void parse(String detailUrl) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Feierwerk");
      event.setLocation("Feierwerk");
      event.setEventUrl(detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, detailUrl);
      if (event.hasArtist()) {
        addEvent(event);
      }
      else {
        LOGGER.info("No artist found");
      }
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Feierwerk";
  }

  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);
    WebElement contentElement = null;
    try {
      contentElement = getDriver().findElement(new By.ByClassName("inner-event"));
    }
    catch (Exception e) {
      contentElement = getDriver().findElement(new By.ByClassName("event-desc"));
    }
    try {
      //artist
      WebElement titleElement = contentElement.findElement(new By.ByTagName("h3"));
      String artist = titleElement
          .getText();
      artist = StringUpperFirstCharCall.upperWords(artist);
      event.setArtist(artist);
    }
    catch(Exception e ) {
      try {
        WebElement titleElement = contentElement.findElement(new By.ByTagName("h2"));
        String artist = titleElement
            .getText()
            .replaceAll("^\\s", "")
            .replaceAll("\\s$", "");
        artist = StringUpperFirstCharCall.upperWords(artist);
        event.setArtist(artist);
      }
          catch (Exception e2) {
            LOGGER.warn("Problem derive artist " + e.getMessage());
        }
    }


    // Stil
    try {
    WebElement styleElement = contentElement.findElement(new By.ByClassName("artiststyle"));
    String styleContent = styleElement.getAttribute("innerHTML");
    styleContent = styleContent.replaceAll("\\s"," " );
    Matcher subTypeMatcher=PATTERN_SUB_TYPE.matcher(styleContent);
    if (subTypeMatcher.find()) {
      event.setSubType(subTypeMatcher.group(1).replaceAll(" ", ""));
    }

    // artistbase
    WebElement artistBaseElement = contentElement.findElement(new By.ByClassName("artisthbase"));
    String artistBaseContent = artistBaseElement.getText();
    }
    catch(Exception e) {
      LOGGER.warn("Problem derive artist info "  + e.getMessage());
    }

    // description
    try {
    List<WebElement> descriptionElements = contentElement.findElements(new By.ByTagName("p"));
    for (WebElement descriptionElement: descriptionElements) {
      String cssClass = descriptionElement.getAttribute("class");
      if (cssClass == null||cssClass.isEmpty()) {
        String descriptionContent = descriptionElement.getText();
        event.setContent(descriptionContent);
        break;
      }
    }
    }
    catch(Exception e) {
      LOGGER.info("Problem derive description");
    }
    //
    try {
    WebElement linkElement = contentElement.findElement(new By.ByClassName("artist-url-list"));
    List<WebElement> linkElements = linkElement.findElements(new By.ByClassName("artisturl"));
    for (WebElement link: linkElements) {
      event.addOtherUrl(link.getAttribute("href"));
    }
    }
    catch(Exception e) {
      LOGGER.info("Problem derive links");
    }

    //youtube event-video-top
    try {
    WebElement iframeElement = contentElement.findElement(new By.ByClassName("event-video-top"))
        .findElement(new By.ByTagName("iframe"));
    String iframeUrl=iframeElement.getAttribute("src");
    event.setArtistUrl(iframeUrl);
    }
    catch(Exception e) {
      LOGGER.info("Problem derive iframe");
    }
    //location
    WebElement dateElement = getDriver().findElement(new By.ByClassName("event-date-location-detail"));
    try {
      String location = dateElement.findElement(new By.ByTagName("h4")).getText();
      if (location!=null && !location.isEmpty()) {
        event.setLocation("Feierwerk: " + location);
      }
    }
    catch(Exception e) {
      LOGGER.info("Problem derive location");
    }
    //date
    try {

      String dateContent = dateElement.getAttribute("innerHTML");
      event.setStartTime(parseDate(dateContent));
    }
    catch(Exception e) {
      LOGGER.info("Problem derive startDate");
    }

    //

  }

  private LocalDateTime parseDate(String content) {
    int minute=0;
    int hour = 0;
    int year =2022;
    int month = 6;
    int day = 1;
    Matcher dateMatcher = PATTERN_DATE.matcher(content);
    if (dateMatcher.find()) {
      day = Integer.parseInt(dateMatcher.group(1));
      month = Integer.parseInt(dateMatcher.group(2));
      year = Integer.parseInt(dateMatcher.group(3));
    }
    else {
      return null;
    }
    Matcher timeMatcher = PATTERN_TIME.matcher(content);
    if (timeMatcher.find()) {
      hour= Integer.parseInt(timeMatcher.group(1));
      minute = Integer.parseInt(timeMatcher.group(2));
    }
    return LocalDateTime.of(year, month, day, hour, minute);
  }

}
