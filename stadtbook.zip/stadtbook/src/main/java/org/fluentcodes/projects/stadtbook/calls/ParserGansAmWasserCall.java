package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.fluentcodes.projects.stadtbook.parser.MonthConversion;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserGansAmWasserCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserGansAmWasserCall.class);
  public static final String LIVEKONZERT = "Livekonzert: ";
  public static final String DJ_ABEND = "DJ Abend: ";
  public static final String WORKSHOP = "Workshop: ";
  private static Pattern PATTERN_DATE = Pattern.compile("([\\d]+)\\. (.*) (\\d\\d\\d\\d)");
  private static Pattern PATTERN_TIME = Pattern.compile("(\\d\\d):(\\d\\d)");

  public ParserGansAmWasserCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    while (getCurrentDate().isBefore(getStopDate())) {
      parse("https://www.gansamwasser.de/programm-juni");
      setCurrentDate(getCurrentDate().plusMonths(1));
    }
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("cc-m-hgrid-column"));

    boolean flag = false;

    for (WebElement element : elements) {
      EventParsed event = parseElement(element);
      if (event == null) {
        continue;
      }
      event.setEventUrl(url);
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }

  @Override
  public String fetchParseType() {
    return hasParseType() ? getParseType() : "GansAmWasser";
  }

  private EventParsed parseElement(WebElement element) {
    EventParsed event = new EventParsed();
    event.setOriginal(true);
    event.setPersist(true);
    event.setSource("GansAmWasser");
    event.setLocation("Gans am Wasser");
    String elementContent = element.getAttribute("innerHTML");
    try {
      WebElement headerElement = element.findElement(new By.ByTagName("h2"));
      String artist = headerElement.getText();
      if (artist.startsWith(LIVEKONZERT)) {
        artist = artist.replace(LIVEKONZERT, "");
        event.setArtist(artist);
        event.setType(Types.KONZERTE.getDefault());
      } else if (artist.startsWith(DJ_ABEND)) {
        artist = artist.replace(DJ_ABEND, "");
        event.setArtist(artist);
        event.setType(Types.PARTY.getDefault());
      }
      else if (artist.startsWith("Yoga")) {
        event.setArtist(artist);
        event.setType(Types.SPORT.getDefault());
      }
      else if (artist.startsWith("Open Mic")) {
        event.setArtist(artist);
        event.setType(Types.KONZERTE.getDefault());
      }
      else if (artist.startsWith(WORKSHOP)) {
        artist = artist.replace(WORKSHOP, "");
        event.setArtist(artist);
        event.setType(Types.SONSTIGE.getDefault());
      }
      else if (artist.startsWith("Kasperletheater")) {
        event.setArtist(artist);
        event.setType(Types.KINDER.getDefault());
      }
      else {
        LOGGER.info(artist);
      }
    }
    catch (Exception e) {
      LOGGER.error(e.getMessage());
      return null;
    }

    List<WebElement> textElements = element.findElements(new By.ByTagName("span"));
    StringBuilder content = new StringBuilder();
    for (WebElement textElement: textElements) {
      content.append(textElement.getText());
    }
    // j-text Time
    List<WebElement> otherElements = element.findElements(new By.ByClassName("j-text"));
    int hour = 0;
    int minute = 0;
    for (WebElement otherElement : otherElements) {
      List<WebElement> contentElements = otherElement.findElements(new By.ByTagName("p"));

      for (WebElement textElementCheck : contentElements) {
        String text = textElementCheck.getText();
        if (text.contains("Uhr")) {
          Matcher matcher = PATTERN_TIME.matcher(text);
          if (matcher.find()) {
            hour = Integer.parseInt(matcher.group(1));
            minute = Integer.parseInt(matcher.group(2));
          }
          continue;
        }
        if (text.replaceAll("\\s", "").isEmpty()) {
          continue;
        }
        if (text.contains("Gefördert")) {
          break;
        }
        content.append(text);
      }
    }
    if (content.length() > 0) {
      event.setContent(content.toString());
    }
    WebElement dateElement = element.findElement(new By.ByClassName("j-calltoaction-link"));
    String dateValue = dateElement.getAttribute("data-title");
    Matcher dateMatcher = PATTERN_DATE.matcher(dateValue);
    if (dateMatcher.find()) {
      int day = Integer.parseInt(dateMatcher.group(1));
      String monthString = dateMatcher.group(2);
      int month = MonthConversion.findGerman(monthString).ordinal()+1;
      int year = Integer.parseInt(dateMatcher.group(3));
      event.setStartTime(LocalDateTime.of(year, month, day, hour, minute));
    }
    return event;
  }
}


