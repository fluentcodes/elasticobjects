package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserGansWoAndersCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserGansWoAndersCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\. (.*) (\\d\\d\\d\\d)");
  private static Pattern PATTERN_PLZ = Pattern.compile("(.*) (\\d\\d\\d\\d\\d) (.*)");
  private List<LocalDate> localDates = new ArrayList<>();



  public ParserGansWoAndersCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parse("https://www.ganswoanders.de/kulturprogramm/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("_3UcEm"));
    for (WebElement element : elements) {
      try {
        EventParsed event = parseElement(element);
        event.setEventUrl(url);
        if (event != null) {
          addEvent(event);
        }
      }
      catch(Exception e) {
        System.out.println(e.getMessage());
      }
      if (isTest()) {
        break;
      }
    }
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"GansWoanders";
  }

  private EventParsed parseElement(WebElement element) {
    EventParsed event = new EventParsed();
    event.setOriginal(true);
    event.setPersist(true);
    event.setSource("GansWoanders");
    event.setLocation("Gans Woanders");
    String content = element.getAttribute("innerHTML").replaceAll("<", "\n<");
    
    return event;
  }

}
