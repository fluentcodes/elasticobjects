package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Locations;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.fluentcodes.projects.stadtbook.parser.MonthConversion;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserInMunchenCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserInMunchenCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\. (.*) (\\d\\d\\d\\d)");
  private static Pattern PATTERN_PLZ = Pattern.compile("(.*) (\\d\\d\\d\\d\\d) (.*)");
  private List<LocalDate> localDates = new ArrayList<>();
  private int changeDatePosition = 0;
  private int startPosition = 0;
  static Pattern TITLE_PATTERN = Pattern.compile("^»(.*?)«(.*)");
  static List<String> permanent = Arrays.asList(
      "Digitales Kinderangebot"
  );


  public ParserInMunchenCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    while (getCurrentDate().isBefore(getStopDate())) {
      parse();
      setCurrentDate(getCurrentDate().plusDays(1));
    }
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  void parse() {
    parse("https://events.in-muenchen.de/region/?suche&datum1=" + getCurrentDate().getDayOfMonth() + "." + getCurrentDate().getMonth().getValue() + "." + getCurrentDate().getYear());
    if (isTest()) {
      setCurrentDate(getStopDate());
    }
    int size = 20;
    try {
      while (parse("https://events.in-muenchen.de/region/?os=" + size + "&send=foo")) {
        size = size + 20;
      }
    }
    catch (Exception e) {
      try {
        Thread.sleep(1000);
      } catch (InterruptedException ex) {
        ex.printStackTrace();
      }
      e.printStackTrace();
    }
  }

  private boolean parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> dateElements = getDriver().findElements(new By.ByClassName("liste-datum"));
    localDates = new ArrayList<>();
    for (WebElement dateElement:dateElements) {
      String dateString = dateElement.findElement(new By.ByTagName("span")).getText();
      Matcher dateMatcher = PATTERN_DATE.matcher(dateString);
      if (dateMatcher.find())  {
        int day = Integer.parseInt(dateMatcher.group(1));
        String monthString = dateMatcher.group(2);
        int month = MonthConversion.findGerman(monthString).ordinal()+1;
        int year = Integer.parseInt(dateMatcher.group(3));
        LocalDate myLocalDate = LocalDate.of(year, month, day);
        localDates.add(myLocalDate);
        if (localDates.size() == 1) {
          Point point = dateElement.getLocation();
          startPosition = point.y;
        }
        else if (localDates.size()>1) {
          Point point = dateElement.getLocation();
          changeDatePosition = point.y;
          System.out.println("changeDate " + changeDatePosition);
        }
      }
    }
    if (!localDates.get(0).equals(getCurrentDate())) {
      return false;
    }

    List<WebElement> elements = getDriver().findElements(new By.ByClassName("eventlist_row"));
    boolean flag = false;

    for (WebElement element : elements) {
      //String elementContent = element.getAttribute("innerHTML");
      try {
        if (element.getLocation().y < startPosition) {
          continue;
        }
        if (changeDatePosition > 0 && changeDatePosition < element.getLocation().y) {
          changeDatePosition = 0;
          return false;
        }
        EventParsed event = parseElement(element);
        if (event != null) {
          addEvent(event);
        }
      }
      catch(Exception e) {
        System.out.println(e.getMessage());
      }
      if (isTest()) {
        break;
      }
    }
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    return true;
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"inmuenchen";
  }

  private EventParsed parseElement(WebElement element) {

    EventParsed event = new EventParsed();
    event.setOriginal(false);
    event.setSource("inmuenchen");
    WebElement titleElement = element.findElement(new By.ByClassName("id-Teaser-el-content-headline"));
    WebElement titleLinkElement = element.findElement(new By.ByTagName("a"));
    String titleLinkIn = titleLinkElement.getAttribute("href");
    String title = titleLinkElement.getText();
    title = StringUpperFirstCharCall.upperWords(title);

    event.setSourceEventUrl(titleLinkIn);

    //location
    List<WebElement> infoElements = element.findElements(new By.ByClassName("info-item"));
    String  location = infoElements.get(0).getText();
    String upperLocation = StringUpperFirstCharCall.upperWords(location.replaceAll("_"," "));
    if (Locations.skip(upperLocation)) {
      return null;
    }
    if (location.matches("Backstage")) {
      event.setPersist(false);
    }
    event.setLocation(upperLocation);

    WebElement descriptionElement = element.findElement(new By.ByClassName("id-link-astext"));
    String description = descriptionElement.getText();
    String descriptionTitle = "";
    Matcher titleMatcher = TITLE_PATTERN.matcher(description);
    if (titleMatcher.find()) {
      description = titleMatcher.group(2).replaceAll("^[\\.,: ]*", "");
      descriptionTitle = titleMatcher.group(1);
    }
    event.setContent(description);



    int select = 1;
    String time = infoElements.get(select).getText();
    if (time.contains(":")) {
      String[] times = time.split(":");
      int hour = Integer.parseInt(times[0].replaceAll("[^\\d]", ""));
      int min = Integer.parseInt(times[1].replaceAll("[^\\d]", ""));
      LocalDateTime startTime = getCurrentDate().atTime(hour, min);
      event.setStartTime(startTime);
    }
    else {
      LocalDateTime startTime = getCurrentDate().atTime(0, 0);
      event.setStartTime(startTime);
    }
    if (title.length()>100) {
      title = title.substring(0, 99);
    }
    for (int i = 0; i<infoElements.size();i++) {
      WebElement info = infoElements.get(i);
      String content = info.getAttribute("innerHTML");
      if (content.contains("fa fa-tag fa-fw")) {
        String type = content
            .replaceAll(".*</i>", "")
                .replaceAll("<.*", "")
            .replaceAll("^\\s+", "");

        if (type.matches("(Klassik|Tollwood|Boulevard / Komödie|Kindertheater)")) {
          event.setSubType(type);
        }
        select = i;
        type = Types.getDefault(type);
        event.setType(type);
        if (type.matches("Konzerte|Galerien|Kabarett")) {
          event.setArtist(title);
          event.setTitle(descriptionTitle);
        }
        else if (!descriptionTitle.isEmpty()) {
          event.setArtist(title);
          event.setTitle(descriptionTitle);
        }
        else {
          event.setTitle(title);
          event.setArtist("");
        }
        if (type.matches("(Theater|Literatur|Konzerte|Galerien|Kabarett|Märkte|Führungen|Sport|Museen|Kinder|Festivals)")) {
          event.setPersist(true);
        }
        else {
          event.setPersist(false);
        }
        break;
      }
    }


    if (!event.hasTitle() && !event.hasArtist()) {
      event.setTitle(title);
      event.setArtist("");
    }

    event.setArtistTitle();
    select = select+1;
    if (infoElements.size()>select+1) {
      WebElement info = infoElements.get(select);
      String content = info.getAttribute("innerHTML");
      String notice = info.getText();
      event.setNotice(notice);
    }
    return event;
  }

}
