package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserLustspielhausCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserLustspielhausCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.(\\d\\d)\\.(\\d\\d\\d\\d)");
  private static Pattern PATTERN_AMOUNT = Pattern.compile("\\((\\d\\d):(\\d\\d)h .* (\\d\\d),(\\d\\d) €\\)");
  private static Pattern PATTERN_TITLE = Pattern.compile("<strong>(.*)</strong>");
  public ParserLustspielhausCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    while (getCurrentDate().isBefore(getStopDate())) {
      String url = "https://www.lustspielhaus.de/programm/" + getCurrentDate().getMonth().getValue()+ "/" + getCurrentDate().getYear();
      parse(url);
      setCurrentDate(getCurrentDate().plusMonths(1));
    }
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Lustspielhaus";
  }

  public void parse(String url) {
    try {
      getDriver().get(url);
    }
    catch (Exception e) {
      throw new EoException(e.getMessage());
    }
    List<WebElement> links = getDriver().findElements(new By.ByClassName("text-dark"));
    List<String> urls = new ArrayList<>();
    for (WebElement element : links) {
      urls.add(element.getDomAttribute("href"));
    }
    boolean parseFlag = true;
    for (String artistUrl: urls) {
      if (parseFlag) {
        try {
          addEvent(parseEvent(artistUrl));
        }
        catch (Exception e) {
          System.out.println(e.getMessage());
        }
      }
      else {
        closeDriver();
        return;
      }
      if (isTest()) {
        parseFlag = false;
      }
    }
    closeDriver();
  }

  protected EventParsed parseEvent(final String eventUrl) {
    EventParsed event = new EventParsed();
    event.setPersist(true);
    event.setOriginal(true);
    event.setEventUrl(eventUrl);
    getDriver().get(eventUrl);
    WebElement element = getDriver().findElement(new By.ByClassName("overflow-hidden"));
    event.setContent(element.getAttribute("innerHTML"));
    String title = getDriver().getTitle();
    String[] titles = title.split(" - ", 3);
    if (titles.length!=3) {
      throw new RuntimeException("Title length is " + titles.length + " " + title);
    }
    String location = titles[2].replaceAll(".* - ", "");
    event.setLocation(location);
    event.setTitle(titles[1]);
    event.setArtist(titles[0]);
    event.setArtistTitle();
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("card-body"));
    for (WebElement myElement : elements) {
      String content = myElement.getAttribute("innerHTML");
      if (content.contains("Reservieren")||content.contains("nicht buchbar")) {
        parseDate(event, content);
      }
    }
    if (event.getStartTime() == null) {
      throw new RuntimeException("Could not find startTime for " + event.getArtist() + " - " + event.getTitle());
    }
    event.setType("Kabarett");
    event.addOtherUrl("https://www.youtube.com/results?search_query=" + event.getArtist().replaceAll("\\s", "+"));
    if (!event.hasLocation()) {
      event.setLocation("Lustspielhaus");
    }
    return event;
  }

  private static final void parseTitle(Event event, WebElement descriptionElement) {
    if (descriptionElement == null) {
      return;
    }
    String description = descriptionElement.getAttribute("innerHTML");
    Matcher matcher = PATTERN_TITLE.matcher(description);
    if (matcher.find()) {
      event.setTitle(matcher.group(1));
    }
  }

  public static final void parseDate(EventParsed event, String content) {
    Matcher matcher = PATTERN_DATE.matcher(content);
    int year;
    int month;
    int day;
    if (matcher.find()) {
      System.out.println(matcher.group(1) + " " + matcher.group(2) + " " + matcher.group(3));
      year = Integer.parseInt(matcher.group(3));
      month = Integer.parseInt(matcher.group(2));
      day = Integer.parseInt(matcher.group(1));
    } else {
      throw new RuntimeException("Could not parse!");
    }
    matcher = PATTERN_AMOUNT.matcher(content);
    float price;
    if (matcher.find()) {
      System.out.println(matcher.group(1) + " " + matcher.group(2) + " " + matcher.group(3) + " " + matcher.group(4));
      int hour = Integer.parseInt(matcher.group(1));
      int minute = Integer.parseInt(matcher.group(2));
      event.setPrice(Float.parseFloat(matcher.group(3) + "." + matcher.group(4)));
      event.setStartTime(LocalDateTime.of(year, month, day, hour, minute));
    }
    else {
      throw new RuntimeException();
    }
  }

}
