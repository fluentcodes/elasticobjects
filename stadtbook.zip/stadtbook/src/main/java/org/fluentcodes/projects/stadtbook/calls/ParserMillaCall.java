package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserMillaCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserMillaCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.[ ]*(\\d\\d)\\.[ ]*(\\d\\d\\d\\d).*?//.*//[ ]*Beginn: (\\d\\d):(\\d\\d) Uhr");
  private static Pattern PATTERN_DATE2 = Pattern.compile("(\\d\\d)\\.[ ]*(\\d\\d)\\.[ ]*(\\d\\d\\d\\d).*//.*");

  private static Pattern PATTERN_ARTIST = Pattern.compile("\"name\":\"(.*?)\"");
  private static Pattern PATTERN_TITLE = Pattern.compile("(.*): (.*) - (.*)");
  private static Pattern PATTERN_EVENTS = Pattern.compile("\"(https://www.milla-club.de/konzert-.*?)/\"");

  public ParserMillaCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Milla";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parseForLinks("https://www.milla-club.de/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseForLinks(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    Set<String> urls = new LinkedHashSet<>();
    String bodyText = getDriver().findElement(new By.ByTagName("body")).getAttribute("innerHTML");
    Matcher eventLinkMatcher = PATTERN_EVENTS.matcher(bodyText);
    while (eventLinkMatcher.find()) {
      urls.add(eventLinkMatcher.group(1));
    }
    for (String detailUrl: urls) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Milla");
      event.setLocation("Milla");
      event.setEventUrl(detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, detailUrl);
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }


  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);
    event.setLocationUrl(url);
    String bodyText = getDriver().findElement(new By.ByTagName("body")).getAttribute("innerHTML")
        .replaceAll("<", "\n<");

    Matcher dateMatcher = PATTERN_DATE.matcher(bodyText);
    if (dateMatcher.find()) {
      String all = dateMatcher.group();
      int year = Integer.parseInt(dateMatcher.group(3));
      int month = Integer.parseInt(dateMatcher.group(2));
      int day = Integer.parseInt(dateMatcher.group(1));
      int hour = Integer.parseInt(dateMatcher.group(4));
      int min = Integer.parseInt(dateMatcher.group(5));
      event.setStartTime(LocalDateTime.of(year, month, day, hour, min));
    }
    else {
      Matcher dateMatcher2 = PATTERN_DATE2.matcher(bodyText);
      if (dateMatcher2.find()) {
        String all = dateMatcher2.group();
        int year = Integer.parseInt(dateMatcher2.group(3));
        int month = Integer.parseInt(dateMatcher2.group(2));
        int day = Integer.parseInt(dateMatcher2.group(1));
        LOGGER.info(all);
        event.setStartTime(LocalDateTime.of(year, month, day, 20, 00));
      }
    }
    List<WebElement> metaElements = getDriver().findElements(new By.ByTagName("meta"));
    for (WebElement metaElement : metaElements) {
      String property = metaElement.getAttribute("property");
      if (property == null || property.isEmpty()) {
        continue;
      }
      if (property.equals("og:title")) {
        String artist = metaElement.getAttribute("content");
        if (artist == null || artist.isEmpty()) {
          continue;
        }
        artist = artist.replaceAll(" \\*\\*\\*.*", "");
        Matcher titleMatcher = PATTERN_TITLE.matcher(artist);
        if (titleMatcher.find()) {
          String type = titleMatcher.group(1);
          event.setArtist(titleMatcher.group(2));
          String location = titleMatcher.group(3);
        } else {
          event.setArtist(artist);
        }
        event.setArtistTitle();
      }
      if (property.equals("og:description")) {
        String content = metaElement.getAttribute("content");
        if (content == null || content.isEmpty()) {
          continue;
        }
        if (content.length() > 500) {
          content = content.substring(0, 500);
        }
        event.setContent(content);
      }
    }
  }
}
