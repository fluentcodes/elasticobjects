package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class ParserMuenchenDeCall extends ParserCall {
  private final static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.(\\d\\d)\\.(\\d\\d\\d\\d), (\\d\\d):(\\d\\d)");
  private final static Pattern PATTERN_PLZ = Pattern.compile("(.*) (\\d\\d\\d\\d\\d) (.*)");
  private final static String[] TYPES = new String[]{"Konzerte", "Bühne", "Sport", "Freizeit","Weiterbildung","Kinder"};
  private String type = "Event";
  private List<EventParsed> events = new ArrayList<>();

  public ParserMuenchenDeCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"MuenchenDe";
  }

  @Override
  public Object execute(EOInterfaceScalar eo) {
    parseAndPersist();
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  public void parseAndPersist() {
    try {
      getDriver().close();
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }


  public List<EventParsed> parse() {
    String dayFilter = getCurrentDate().getDayOfMonth() + "." + getCurrentDate().getMonth().getValue() + "." + getCurrentDate().getYear();
    for (String type: TYPES) {
      this.type = type;
      parse(
          "https://www.muenchen.de/veranstaltungen/event/listing.html?what=" + type + "&where=&from=" + dayFilter + "&to=" +
              dayFilter);
    }
    return events;
  }

  private List<EventParsed> parse(String url) {
    getDriver().get(url);//toggle__trigger
    System.out.println("* PARSE " + url);
    /* try {
      WebElement next = getDriver().findElement(new By.ByClassName("toggle__trigger"));
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }*/
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("item"));

    elements = getDriver().findElements(new By.ByClassName("item"));

    for (WebElement element : elements) {
      try {
        String myTypeDom = element.getDomAttribute("data-event-typ");
        String myType = element.getAttribute("data-event-typ");
        String myTypeProp = element.getDomProperty("data-event-typ");
        EventParsed event = parseElement(element);
        event.setSourceParseUrl(url);
        events.add(event);
      }
      catch(Exception e) {
        System.out.println(e.getMessage());
      }
      if (isTest()) {
        break;
      }
    }
    return events;
  }

  private EventParsed parseElement(WebElement element) {
    EventParsed event = new EventParsed();
    event.setSource("muenchen");
    event.setType(type);
    /**String value = element.getAttribute("content");
    String html = element.getAttribute("innerHtml");
    String type = element.getDomAttribute("data-event-typ");
    String title = element.getDomProperty("data-event-name");
    String titleLinkIn = element.getAttribute("data-event-link");
    event.setType(type);*/
    WebElement titleElement = element.findElement(new By.ByClassName("eventinfo--headline"));
    WebElement titleLinkElement = element.findElement(new By.ByTagName("a"));
    String titleLinkIn = titleLinkElement.getAttribute("href");
    String title = titleElement.findElement(new By.ByTagName("h2")).getText();
    event.setTitle(title);
    event.setSourceEventUrl(titleLinkIn);
    // location
    WebElement locationElement = element.findElement(new By.ByClassName("eventinfo--location"));
    String  location = locationElement.getText();
    event.setLocation(location);
    event.setSourceLocationUrl(locationElement.getAttribute("href"));
    WebElement dateTimeElement = element.findElement(new By.ByClassName("eventinfo--time"));
    JavascriptExecutor executor = (JavascriptExecutor) getDriver();
    String dateTime = dateTimeElement.getAttribute("content");
    Matcher dateMatcher = PATTERN_DATE.matcher(dateTime);
    if (dateMatcher.find()) {
      int day = Integer.parseInt(dateMatcher.group(1));
      int month = Integer.parseInt(dateMatcher.group(2));
      int year = Integer.parseInt(dateMatcher.group(3));
      int hour = Integer.parseInt(dateMatcher.group(4));
      int min = Integer.parseInt(dateMatcher.group(5));
      LocalDateTime startTime = LocalDateTime.of(year, month, day, hour, min);
      event.setStartTime(startTime);
    }
    try {
      WebElement ticketElement = element.findElement(new By.ByClassName("button--default"));
      if (ticketElement != null) {
        String ticketUrl = ticketElement.getAttribute("href");
        event.setSourceTicketUrl(ticketUrl);
      }
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }

    return event;
  }

}
