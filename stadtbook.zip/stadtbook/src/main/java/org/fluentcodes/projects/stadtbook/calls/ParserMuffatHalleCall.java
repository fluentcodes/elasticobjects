package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserMuffatHalleCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserMuffatHalleCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.(\\d\\d)\\.<br>");
  private static Pattern PATTERN_TIME = Pattern.compile("Einlass: (\\d\\d)");
  private static Pattern PATTERN_LOCATION = Pattern.compile("Ort: (.*)<sup>");
  private static final Pattern PATTERN_LINKS = Pattern.compile("<a href=\"(.*)\">Info</a>");
  private List<LocalDate> localDates = new ArrayList<>();



  public ParserMuffatHalleCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parse("https://www.muffatwerk.de/de/events/concert");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    WebElement bodyElement = getDriver().findElement(new By.ByTagName("body"));
    String bodyContent = bodyElement.getAttribute("innerHTML");
    LOGGER.info(bodyContent);
    Matcher matcherLinks = PATTERN_LINKS.matcher(bodyContent);
    List<String> urls = new ArrayList<>();
    while (matcherLinks.find()) {
      urls.add(matcherLinks.group(1));
    }

    for (String detailUrl: urls) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("MuffatHalle");
      event.setLocation("Muffat Halle");
      event.setEventUrl("https://www.muffatwerk.de" + detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, "https://www.muffatwerk.de" + detailUrl);
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Muffatwerk";
  }

  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);

    List<WebElement> metaElements = getDriver().findElements(new By.ByTagName("meta"));
    for (WebElement metaElement: metaElements) {
      String property = metaElement.getAttribute("property");
      if (property == null) {
        continue;
      }
      String content = metaElement.getAttribute("content");
      if (content == null) {
        continue;
      }
      if (property.equals("og:title")) {
        event.setArtist(content);
        event.setArtistTitle(content);
      }
      if (property.equals("og:description")) {
        event.setContent(content);
        if (content.contains("leider")) {
          event.setPersist(false);
        }
      }
    }
    List<WebElement> contentElements = getDriver().findElements(new By.ByClassName("entry-normal"));
    for (WebElement contentElement: contentElements) {
      String contentContent = contentElement.getAttribute("innerHTML");
      try {
        WebElement entryElement = contentElement.findElement(new By.ByClassName("entry-content"));
        String entryContent = entryElement.getAttribute("innerHTML");

        // location and time
        WebElement infoElement = contentElement.findElement(new By.ByClassName("entry-info"));
        String infoContent = infoElement.getAttribute("innerHTML");
        event.setLocation(parseLocation(infoContent));
        event.setStartTime(parseDate(infoContent));
        List<WebElement> h4Elements = entryElement.findElements(new By.ByTagName("h4"));
        for (WebElement h4Element: h4Elements) {
          if (h4Element.getText().contains("Verlegt")) {
            continue;
          }
          event.setTitle(h4Element.getText());
          event.setArtistTitle(event.getArtist() + ": " + event.getTitle());
        }
      }
      catch(Exception e) {
        continue;
      }
    }
  }

  private String parseLocation(String infoContent) {
      Matcher locationMatcher = PATTERN_LOCATION.matcher(infoContent);
      if (locationMatcher.find()) {
        return "Muffatwerk " + locationMatcher.group(1);
      }
      return "Muffatwerk";
  }

  private LocalDateTime parseDate(String content) {
    int hour = 0;
    int month = 6;
    int day = 1;
    Matcher dateMatcher = PATTERN_DATE.matcher(content);
    if (dateMatcher.find()) {
      day = Integer.parseInt(dateMatcher.group(1));
      month = Integer.parseInt(dateMatcher.group(2));
    }
    else {
      return null;
    }
    Matcher timeMatcher = PATTERN_TIME.matcher(content);
    if (timeMatcher.find()) {
      hour= Integer.parseInt(timeMatcher.group(1));
    }
    return LocalDateTime.of(2022, month, day, hour, 0);
  }

}
