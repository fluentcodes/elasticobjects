package org.fluentcodes.projects.stadtbook.calls;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.fluentcodes.projects.stadtbook.parser.DateConvert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserRoteSonneCall extends ParserCall {
  public static final String URL = "url";
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserRoteSonneCall.class);
  public static final String START_DATE = "startDate";
  public static final String NAME = "name";
  public static final String PERFORMER = "performer";
  private static DateConvert CONVERTER = new DateConvert("(\\d\\d\\d\\d)-(\\d+)-(\\d+).*?(\\d\\d):(\\d\\d)", new int[]{3,2,1,4,5});


  private static Pattern PATTERN_ARTIST = Pattern.compile("(.*?)<br>(.*)");
  private static Pattern PATTERN_EVENTS = Pattern.compile("\"(https://www.theatron-pfingstfestival.de/portfolio-items/.*?)/\"");

  public ParserRoteSonneCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"RoteSonne";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parseList("https://www.rote-sonne.com//");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseList(String url) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm z");
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<WebElement> eventElements = getDriver().findElements(new By.ByTagName("script"));
    for (WebElement eventElement: eventElements) {
      String type = eventElement.getAttribute("type");
      if (!type.equals("application/ld+json")) {
        continue;
      }
      String typeContent = eventElement.getAttribute("innerHTML");
      EoRoot eo = ObjectProvider.createEo();
      eo.map(typeContent);

      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Rote Sonne");
      event.setLocation("Rote Sonne");
      event.setEventUrl(url);
      event.setType(Types.KONZERTE.getDefault());
      String title = (String) eo.get(NAME);
      title = StringUpperFirstCharCall
          .upperWords(title)
          .replaceAll(" \\|", ",");
      if (title.length()>99) {
        title = title.substring(0,99);
      }
      event.setTitle(title);
      if (eo.hasEo(URL)) {
        event.setEventUrl((String) eo.get(URL));
      }
      if (eo.hasEo(PERFORMER)) {
        Map performer = (Map)eo.get(PERFORMER);
        String performerName = (String)performer.get(PERFORMER);
        if (performerName != null && !performerName.equals("Rote Sonne")) {
          event.setArtist(performerName);
        }
        else {
          event.setType(Types.PARTY.getDefault());
        }
      }
      event.setStartTime(CONVERTER.parse((String)eo.get(START_DATE)));
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }
}
