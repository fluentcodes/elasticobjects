package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserStromCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserStromCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("Datum:</span> (\\d\\d)\\.(\\d\\d).(\\d\\d\\d\\d)");
  private static Pattern PATTERN_TIME = Pattern.compile(" (\\d\\d).(\\d\\d) Uhr");

  private static Pattern PATTERN_IFRAME = Pattern.compile("<iframe .* src=\"https://www.youtube.com/embed/(.*)?feature=oembed\"");
  private List<LocalDate> localDates = new ArrayList<>();



  public ParserStromCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Strom";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parse("https://strom-muc.de/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parse(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    List<String> urls = new ArrayList<>();
    List<WebElement> elements = getDriver().findElements(new By.ByClassName("event-title"));
    for (WebElement element:elements) {
      WebElement linkEement = element.findElement(new By.ByTagName("a"));
      String link = linkEement.getAttribute("href");
      if (link == null) {
        continue;
      }
      urls.add(link);
      if (isTest()) {
        break;
      }
    }
    for (String detailUrl: urls) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Strom");
      event.setLocation("Strom");
      event.setEventUrl(detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, detailUrl);
      addEvent(event);
    }
  }

  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);
    event.setLocationUrl(url);
    WebElement contentElement = getDriver().findElement(new By.ByClassName("gdlr-event-content-wrapper"));
    String contentContent = contentElement.getAttribute("innerHTML");

    //artist
    WebElement titleElement = contentElement.findElement(new By.ByTagName("h1"));
    String artist = titleElement
        .getText();
    artist = StringUpperFirstCharCall.upperWords(artist);
    event.setArtist(artist);
    // Remarks
    List<WebElement> strongElements = contentElement.findElements(new By.ByTagName("strong"));
    for (WebElement remark: strongElements) {
      String remarks = remark.getText();
      if (remarks.contains("abgesagt")) {
        event.setPersist(false);
      }
    }
    List<WebElement> descriptionElements = contentElement.findElements(new By.ByTagName("p"));
    int descriptionLength = 0;
    for (WebElement descriptionElement: descriptionElements) {
      String description = descriptionElement.getText();
      if (description.length()<descriptionLength) {
        continue;
      }
      if (description.length() > 500) {
        description = description.substring(0, 500);
      }
      descriptionLength = description.length();
      event.setContent(description);
    }
    Matcher iframe = PATTERN_IFRAME.matcher(contentContent);
    if (iframe.find()) {
      event.setArtistUrl("https://www.youtube.com/watch?v=" + iframe.group(1));
    }

    WebElement infoElement = getDriver().findElement(new By.ByClassName("gdlr-event-info-wrapper"));
    String infoContent = infoElement.getAttribute("innerHTML");

    if (infoContent == null) {
      return;
    }
    try {
      event.setStartTime(parseDate(infoContent));
    }
    catch (Exception e) {
      event.setContent(e.getMessage());
      event.setPersist(false);
    }
  }

  private LocalDateTime parseDate(String content) {
    int minute=0;
    int hour = 0;
    int year =2022;
    int month = 6;
    int day = 1;
    Matcher dateMatcher = PATTERN_DATE.matcher(content);
    if (dateMatcher.find()) {
      day = Integer.parseInt(dateMatcher.group(1));
      month = Integer.parseInt(dateMatcher.group(2));
      year = Integer.parseInt(dateMatcher.group(3));
    }
    else {
      return null;
    }
    Matcher timeMatcher = PATTERN_TIME.matcher(content);
    if (timeMatcher.find()) {
      hour= Integer.parseInt(timeMatcher.group(1));
      minute = Integer.parseInt(timeMatcher.group(2));
    }
    return LocalDateTime.of(year, month, day, hour, minute);
  }

}
