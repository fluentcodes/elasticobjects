package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserTheatronCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserTheatronCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\.(\\d\\d).*?(\\d\\d):(\\d\\d) h");

  private static Pattern PATTERN_ARTIST = Pattern.compile("^(.*)");
  private static Pattern PATTERN_EVENTS = Pattern.compile("\"(https://www.theatron-pfingstfestival.de/portfolio-items/.*?)/\"");

  public ParserTheatronCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Theatron";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parseForLinks("https://www.theatron-pfingstfestival.de/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseForLinks(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    Set<String> urls = new LinkedHashSet<>();
    String bodyText = getDriver().findElement(new By.ByTagName("body")).getAttribute("innerHTML");
    Matcher eventLinkMatcher = PATTERN_EVENTS.matcher(bodyText);
    while (eventLinkMatcher.find()) {
      urls.add(eventLinkMatcher.group(1));
    }
    for (String detailUrl: urls) {
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Theatron");
      event.setLocation("Theatron");
      event.setEventUrl(detailUrl);
      event.setType(Types.KONZERTE.getDefault());
      parseDetails(event, detailUrl);
      addEvent(event);
      if (isTest()) {
        break;
      }
    }
  }


  void parseDetails(EventParsed event, String url) {
    getDriver().get(url);
    event.setLocationUrl(url);
    String bodyText = getDriver().findElement(new By.ByTagName("body")).getAttribute("innerHTML")
        .replaceAll("<", "\n<");

    List<WebElement> metaElements = getDriver().findElements(new By.ByTagName("meta"));
    for (WebElement metaElement : metaElements) {
      String property = metaElement.getAttribute("property");
      if (property == null || property.isEmpty()) {
        continue;
      }
      if (property.equals("og:description")) {
        String content = metaElement.getAttribute("content");
        if (content == null || content.isEmpty()) {
          continue;
        }

        Matcher artistMatcher = PATTERN_ARTIST.matcher(content);
        if (artistMatcher.find()) {
          String artist = artistMatcher.group(1);
          artist = artist.replaceAll(" ;;.*","");
          event.setArtist(artist);
        }

        Matcher dateMatcher = PATTERN_DATE.matcher(content);
        int end = 0;
        if (dateMatcher.find()) {
          String all = dateMatcher.group();
          int month = Integer.parseInt(dateMatcher.group(2));
          int day = Integer.parseInt(dateMatcher.group(1));
          int hour = Integer.parseInt(dateMatcher.group(3));
          int min = Integer.parseInt(dateMatcher.group(4));
          event.setStartTime(LocalDateTime.of(2022, month, day, hour, min));
          dateMatcher.end();
        }
        content = content.substring(end, content.length());
        if (content.length() > 500) {
          content = content.substring(0, 500);
        }
        event.setContent(content);
      }
    }
  }
}
