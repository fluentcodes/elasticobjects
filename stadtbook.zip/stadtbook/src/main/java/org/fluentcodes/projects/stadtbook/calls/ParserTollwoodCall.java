package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.MonthEnum;
import org.fluentcodes.projects.stadtbook.domain.Thing;
import org.fluentcodes.projects.stadtbook.domain.Types;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserTollwoodCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserTollwoodCall.class);
  private static Pattern PATTERN_DATE = Pattern.compile("(\\d\\d)\\. (.*?) (\\d\\d\\d\\d)");
  private static Pattern PATTERN_TIME = Pattern.compile("(\\d\\d):(\\d\\d)");
  private static Pattern PATTERN_ARTIST = Pattern.compile("^(.*)");
  private static Pattern PATTERN_EVENTS = Pattern.compile("\"(https://www.tollwood.de/veranstaltungen/2022/.*?)/\"");

  public ParserTollwoodCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"Tollwood";
  }

  public Object execute(EOInterfaceScalar eo) {
    check();
    initDriver();
    parseForLinks("https://www.tollwood.de/kalender-sommer-2022/");
    closeDriver();
    mapToResult(eo);
    LOGGER.info("Found " + getEventParsedList().size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

  private void parseForLinks(String url) {
    getDriver().get(url);
    System.out.println("* PARSE " + url);
    Set<String> urls = new LinkedHashSet<>();
    List<WebElement> dayElements = getDriver().findElements(new By.ByClassName("panel-calendar-tile"));
    for (WebElement dayElement: dayElements) {
      String dayString = dayElement
          .findElement(new By.ByClassName("date"))
          .getAttribute("innerHTML");
      Matcher dayMatcher = PATTERN_DATE.matcher(dayString);
      LocalDate eventDate = null;
      if (dayMatcher.find()) {
        int day = Integer.parseInt(dayMatcher.group(1));
        int month = MonthEnum.getInt(dayMatcher.group(2));
        int year = Integer.parseInt(dayMatcher.group(3));
        eventDate = LocalDate.of(year, month, day);
      }
      else {
        continue;
      }
      List<WebElement> tables = dayElement.findElements(new By.ByClassName("table-events"));
      for (WebElement tableElement: tables) {
        String tableText = tableElement.getAttribute("innerHTML");
        List<WebElement> eventElements = tableElement.findElements(new By.ByTagName("tr"));
        parseEvents(eventElements, eventDate);
      }
      if (isTest() && !getEventParsedList().isEmpty()) {
        break;
      }
    }
  }

  public void parseEvents(List<WebElement> eventElements, LocalDate eventDate) {
    for (WebElement eventElement : eventElements) {
      String eventText = eventElement.getAttribute("innerHTML");
      EventParsed event = new EventParsed();
      event.setOriginal(true);
      event.setPersist(true);
      event.setSource("Tollwood");
      event.setLocation("Tollwood");
      event.setType(Types.KONZERTE.getDefault());
      event.setStartTime(LocalDateTime.of(eventDate.getYear(), eventDate.getMonth(), eventDate.getDayOfMonth(),0,0));
      parseDetails(event, eventElement);
      if (event.hasArtist()) {
        addEvent(event);
      }
    }
  }

  void parseDetails(EventParsed event, WebElement eventElement) {
    String eventString = eventElement.getAttribute("innerHTML");
    if (eventString.contains("<th>Titel</th>")) {
      return;
    }
      String artist = eventElement.findElement(new By.ByClassName("cell-title")).getAttribute("innerHTML");
      event.stripArtist(artist);
    String type = eventElement.findElement(new By.ByClassName("cell-category"))
        .getAttribute("innerHTML");
    type = Types.getDefault(Thing.strip(type));
    event.setType(type);
    String location= eventElement.findElement(new By.ByClassName("cell-location")).getAttribute("innerHTML");
    event.setLocation("Tollwood - " + Thing.strip(type));
    String time = eventElement.findElement(new By.ByClassName("cell-time")).getAttribute("innerHTML");
    Matcher timeMatcher = PATTERN_TIME.matcher(time);
    if (timeMatcher.find()) {
      int hour = Integer.parseInt(timeMatcher.group(1));
      int minute = Integer.parseInt(timeMatcher.group(2));
      event.setStartTime(event.getStartTime().plusHours(hour).plusMinutes(minute));
    }
    //event.setLocation("Tollwood - " + type);
    String eventUrl = eventElement.findElement(new By.ByClassName("cell-details")).getAttribute("innerHTML");
    Matcher eventMatcher = PATTERN_EVENTS.matcher(eventUrl);
    if (eventMatcher.find()) {
      event.setEventUrl(eventMatcher.group(1));
    }
    if (location.equals("Kinderzelt")) {
      event.setType("Kinder");
    }
  }
}
