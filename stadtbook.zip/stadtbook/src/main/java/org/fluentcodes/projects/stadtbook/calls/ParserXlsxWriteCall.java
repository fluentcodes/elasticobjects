package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.ParserCall.INPUT_DIR;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserXlsxWriteCall extends XlsxWriteCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserXlsxWriteCall.class);
  public ParserXlsxWriteCall(String fileName) {
    super(INPUT_DIR, fileName);
  }

  @Override
  public String execute(EOInterfaceScalar eo) {
    return super.execute(eo);
   }

}
