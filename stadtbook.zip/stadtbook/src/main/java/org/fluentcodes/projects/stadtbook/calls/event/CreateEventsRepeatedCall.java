package org.fluentcodes.projects.stadtbook.calls.event;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxReadCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.calls.ParserCall;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.fluentcodes.projects.stadtbook.domain.EventRepeated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreateEventsRepeatedCall extends ParserCall {
  private static final Logger LOGGER = LoggerFactory.getLogger(CreateEventsRepeatedCall.class);
  private static final String FILE_NAME = "Repeated.xlsx";
  private static final String EVENTS_REPEATED_PATH = "(List,EventRepeated)event";

  private List<LocalDate> localDates = new ArrayList<>();

  public CreateEventsRepeatedCall() {
    super();
  }

  @Override
  public String fetchParseType() {
    return hasParseType()? getParseType():"RepeatedEvents";
  }

  public Object execute(EOInterfaceScalar eo) {
    EoRoot repeatedEvents = ObjectProvider.createEo();
    XlsxReadCall readCall = new XlsxReadCall(INPUT_DIR, FILE_NAME);
    readCall.setTargetPath(EVENTS_REPEATED_PATH);
    readCall.getListParams().setRowHead(0);
    readCall.execute(repeatedEvents);
    List<EventRepeated> eventRepeatedList = (List<EventRepeated>)repeatedEvents.get("event");
    for (EventRepeated eventRepeated: eventRepeatedList) {
      if (!eventRepeated.hasUrl()) {
        continue;
      }
      if (!eventRepeated.hasRepetition()) {
        continue;
      }
      if (eventRepeated.getRepetition().startsWith("no")) {
        continue;
      }
      createEvents(eventRepeated);
    }
    mapToResult(eo);
    LOGGER.info("Created " + ((List)eo.get(getTargetPath())).size() + " between " + getStartDate() + " and " + getStopDate());
    return "";
  }

  public void createEvents(EventRepeated eventRepeated) {

    LocalDate startDate = eventRepeated.deriveStartDate(getStartDate());
    LocalDate stopDate = eventRepeated.deriveStopDate(getStopDate());
    LocalDate date = startDate;
    String[] repetitions = eventRepeated.getRepetition().split(";");
    List<CronTabs> cronTabs = new ArrayList<>();
    for (String repetition: repetitions) {
      cronTabs.add(new CronTabs(repetition));
    }
    List<LocalDateTime> localDateTimes = new ArrayList<>();
    for (CronTabs cronTab: cronTabs) {
      localDateTimes.addAll(cronTab.deriveDates(startDate, stopDate));
    }

    for (LocalDateTime localDateTime: localDateTimes) {
      addEvent(new EventParsed(eventRepeated, localDateTime));
      if (isTest()) {
        break;
      }
    }

  }

  @Override
  public void setByParameter(String values) {

  }

}
