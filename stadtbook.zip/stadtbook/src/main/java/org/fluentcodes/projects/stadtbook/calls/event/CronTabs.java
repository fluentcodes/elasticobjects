package org.fluentcodes.projects.stadtbook.calls.event;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;

public class CronTabs {
  final List<Integer> months;
  final List<Integer> days;
  final List<Integer> daysOfTheWeek;
  final List<Integer> hours;
  final List<Integer> minutes;
  public CronTabs(final String crontab) {
    String[] tabs = crontab.split(" ");
    if (tabs.length != 5) {
      throw new EoException("Length is " + tabs.length + " and expected is 5 for '" + crontab + "'");
    }
    try {
      minutes = createList(tabs[0]);
      if (minutes.isEmpty()) {
        for (int i=0; i<60;i++) {
          minutes.add(i);
        }
      }
    }
    catch (Exception e) {
      throw new EoException("Problem creating minutes list with '" + crontab + "': " + e.getMessage());
    }
    try {
      hours = createList(tabs[1]);
      if (hours.isEmpty()) {
        for (int i=0; i<24;i++) {
          hours.add(i);
        }
      }
    }
    catch (Exception e) {
      throw new EoException("Problem creating hours list with '" + crontab + "': " + e.getMessage());
    }
    try {
      days = createList(tabs[2]);
    }
    catch (Exception e) {
      throw new EoException("Problem creating days list with '" + crontab + "': " + e.getMessage());
    }
    try {
      months = createList(tabs[3]);
    }
    catch (Exception e) {
      throw new EoException("Problem creating months list with '" + crontab + "': " + e.getMessage());
    }
    try {
      daysOfTheWeek = createList(tabs[4]);
    }
    catch (Exception e) {
      throw new EoException("Problem creating days of week list with '" + crontab + "': " + e.getMessage());
    }
  }

  private List<Integer> createList(final String tab) {
    if (tab==null || tab.isEmpty()) {
      throw new EoException("Empty tab");
    }
    List<Integer> integerList = new ArrayList<>();
    if (tab.equals("*")) {
      return integerList;
    }
    if (tab.matches("\\d+")) {
      integerList.add(Integer.parseInt(tab));
      return integerList;
    }

    if (tab.contains(",")) {
      String[] entries = tab.split(",");
      for (String entry: entries) {
        integerList.add(Integer.parseInt(entry));
      }
      return integerList;
    }

    if (tab.contains("-")) {
      String[] entries = tab.split("-");
      if (entries.length != 2) {
        throw new EoException("Length for range is " + entries.length + " and expected is 2");
      }
      Integer start = Integer.parseInt(entries[0]);
      Integer stop = Integer.parseInt(entries[1]);
      for (int i=0; i<= stop; i++) {
        integerList.add(i);
      }
      return integerList;
    }
    throw new EoException("Not parsable entry for '" + tab + "'!");
  }

  public List<LocalDateTime> deriveDates(LocalDate start, LocalDate stop) {
    List<LocalDateTime> localDateTimes = new ArrayList<>();
    stop = stop.plusDays(1);
    LocalDate current = start;
    while (current.isBefore(stop)) {
      if (!months.isEmpty()) {
        int month = current.getMonthValue();
        if (!months.contains(month)) {
          current = current.plusDays(1);
          continue;
        }
      }
      if (!days.isEmpty()) {
        int day = current.getDayOfMonth();
        if (!days.contains(day)) {
          current = current.plusDays(1);
          continue;
        }
      }
      if (!daysOfTheWeek.isEmpty()) {
        int day = current.getDayOfWeek().getValue();
        if (!daysOfTheWeek.contains(day)) {
          current = current.plusDays(1);
          continue;
        }
      }
      for (int hour: hours) {
        for (int min: minutes) {
          localDateTimes.add(current.atStartOfDay().plusHours(hour).plusMinutes(min));
        }
      }
      current = current.plusDays(1);
    }
    return localDateTimes;
  }
}
