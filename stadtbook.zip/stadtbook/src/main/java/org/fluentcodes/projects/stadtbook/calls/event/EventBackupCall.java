package org.fluentcodes.projects.stadtbook.calls.event;

import static org.fluentcodes.projects.stadtbook.calls.CreateHtmlPageDayCall.DB_H2_FILE;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.EVENTS_PATH;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.INPUT_DIR;
import static org.fluentcodes.projects.stadtbook.calls.event.EventBackupRestoreCall.FILE_NAME;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.calls.CallImpl;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventBackupCall extends CallImpl {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventBackupCall.class);
  public EventBackupCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    DbSqlReadCall call = new DbSqlReadCall(DB_H2_FILE, "AllEvents");
    call.getListParams().setRowEnd(100000);
    call.setTargetPath(EVENTS_PATH);
    call.execute(eo);

    EOInterfaceScalar eventsEo = eo.getEo(EVENTS_PATH);

    XlsxWriteCall writeCall = new XlsxWriteCall(INPUT_DIR, FILE_NAME);
    writeCall.setTargetPath(getTargetPath());
    writeCall.getListParams().setRowHead(0);
    writeCall.execute(eventsEo);
    LOGGER.info("written " + ((EoChild)eventsEo).size() + " to " + FILE_NAME);

    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

}
