package org.fluentcodes.projects.stadtbook.calls.event;

import static org.fluentcodes.projects.stadtbook.calls.EventCall.EVENTS_PARSED_PATH;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.EVENTS_PATH;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.INPUT_DIR;
import static org.fluentcodes.projects.stadtbook.calls.postaladdress.PostalAddressReadAndPersistCall.DB_MODELS_H2_FILE;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.calls.CallImpl;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxReadCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventBackupRestoreCall extends CallImpl {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventBackupRestoreCall.class);
  public static final String FILE_NAME = "AllEvent.xlsx";

  public EventBackupRestoreCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {

    XlsxReadCall readCall = new XlsxReadCall(INPUT_DIR, FILE_NAME);
    readCall.setTargetPath(EVENTS_PATH);
    readCall.getListParams().setRowHead(0);
    readCall.execute(eo);
    EoChild eventsEo = (EoChild)eo.getEo(EVENTS_PATH);
    DbModelWriteCall call = new DbModelWriteCall(DB_MODELS_H2_FILE);
    for (String key: eventsEo.keys()) {
      EOInterfaceScalar eventEo = eventsEo.getEo(key);
      call.execute(eventEo);
    }
    LOGGER.info("written " + eventsEo.size() + " to " + FILE_NAME);
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

}
