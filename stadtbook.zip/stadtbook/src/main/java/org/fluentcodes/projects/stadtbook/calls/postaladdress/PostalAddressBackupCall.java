package org.fluentcodes.projects.stadtbook.calls.postaladdress;

import static org.fluentcodes.projects.stadtbook.calls.CreateHtmlPageDayCall.DB_H2_FILE;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.INPUT_DIR;
import static org.fluentcodes.projects.stadtbook.calls.postaladdress.PostalAddressReadAndPersistCall.PATH;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.calls.CallImpl;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostalAddressBackupCall extends CallImpl {
  private static final Logger LOGGER = LoggerFactory.getLogger(PostalAddressBackupCall.class);
  public PostalAddressBackupCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    DbSqlReadCall call = new DbSqlReadCall(DB_H2_FILE, "AllPostalAddress");
    call.getListParams().setRowEnd(100000);
    call.setTargetPath(PATH);
    call.execute(eo);

    EOInterfaceScalar postalAddressEo = eo.getEo(PATH);
    String fileName = "AllPostalAddress.xlsx";

    XlsxWriteCall writeCall = new XlsxWriteCall(INPUT_DIR, fileName);
    writeCall.setTargetPath(getTargetPath());
    writeCall.getListParams().setRowHead(0);
    writeCall.execute(postalAddressEo);
    LOGGER.info("written " + ((EoChild)postalAddressEo).size() + " to " + fileName);

    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

}
