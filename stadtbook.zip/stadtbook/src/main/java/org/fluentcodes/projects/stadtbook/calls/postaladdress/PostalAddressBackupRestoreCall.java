package org.fluentcodes.projects.stadtbook.calls.postaladdress;

import static org.fluentcodes.projects.stadtbook.calls.EventCall.INPUT_DIR;
import static org.fluentcodes.projects.stadtbook.calls.postaladdress.PostalAddressReadAndPersistCall.DB_MODELS_H2_FILE;
import static org.fluentcodes.projects.stadtbook.calls.postaladdress.PostalAddressReadAndPersistCall.PATH;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.calls.CallImpl;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxReadCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostalAddressBackupRestoreCall extends CallImpl {
  private static final Logger LOGGER = LoggerFactory.getLogger(PostalAddressBackupRestoreCall.class);
  public PostalAddressBackupRestoreCall() {
    super();
  }

  public Object execute(EOInterfaceScalar eo) {
    String fileName = "AllPostalAddress.xlsx";
    XlsxReadCall readCall = new XlsxReadCall(INPUT_DIR, fileName);
    readCall.setTargetPath(PATH);
    readCall.getListParams().setRowHead(0);
    readCall.execute(eo);
    EoChild postalAddressesEo = (EoChild)eo.getEo(PATH);
    DbModelWriteCall call = new DbModelWriteCall(DB_MODELS_H2_FILE);
    for (String key: postalAddressesEo.keys()) {
      EOInterfaceScalar postalAddressEo = postalAddressesEo.getEo(key);
      call.execute(postalAddressEo);
    }
    LOGGER.info("written " + postalAddressesEo.size() + " to " + fileName);
    return "";
  }

  @Override
  public void setByParameter(String values) {

  }

}
