package org.fluentcodes.projects.stadtbook.domain;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Map;

public class DayCount {
  public static final String EVENT_DAY = "eventDay";
  public static final String COUNT = "count";
  LocalDateTime day;
  long count;
  public DayCount() {

  }
  public DayCount(Map<String, Object> dayMap) {
    day = (LocalDateTime)  dayMap.get(EVENT_DAY);
    count = (Long)  dayMap.get(COUNT);
  }

  public DayCount(LocalDateTime day) {
    this.day = day;
    long count = -1L;
  }

  public LocalDateTime getDay() {
    return day;
  }

  public void setDay(LocalDateTime day) {
    this.day = day;
  }

  public long getCount() {
    return count;
  }

  public void setCount(long count) {
    this.count = count;
  }

  public boolean isMonday() {
    return day.getDayOfWeek() == DayOfWeek.MONDAY;
  }
  public boolean isSunday() {
    return day.getDayOfWeek() == DayOfWeek.SUNDAY;
  }

  public boolean hasEvent() {
    return count>0;
  }

  public int getDayOfMonth() {
    return day.getDayOfMonth();
  }

  public String deriveCalenderDay() {
    return Integer.valueOf(day.getYear()).toString() + day.getMonth() + day.getDayOfMonth();
  }

  public LocalDateTime deriveFirstMonday() {
    LocalDateTime firstDayOfMonth = LocalDateTime.of(day.getYear(), day.getMonth(),1,0,0);
    while (firstDayOfMonth.getDayOfWeek()!=DayOfWeek.MONDAY) {
      firstDayOfMonth = firstDayOfMonth.minusDays(1);
    }
    return firstDayOfMonth;
  }

  public LocalDateTime deriveLastSunday() {
    LocalDateTime lastDayOfMonth = LocalDateTime.of(day.getYear(), day.getMonth(),day.getDayOfMonth(),0,0);
    while (lastDayOfMonth.getDayOfWeek()!=DayOfWeek.SUNDAY) {
      lastDayOfMonth = lastDayOfMonth.plusDays(1);
    }
    return lastDayOfMonth;
  }

  public boolean isSameDateTime(LocalDateTime localDateTime) {
    return day.toString().equals(localDateTime.toString());
  }
}
