package org.fluentcodes.projects.stadtbook.domain;

import static org.fluentcodes.projects.stadtbook.domain.Thing.strip;

import java.time.LocalDateTime;
import java.util.Locale;
import org.fluentcodes.projects.elasticobjects.calls.values.StringUpperFirstCharCall;

public class Event {
  private Long id;
  private String naturalId;
  private String location;
  private LocalDateTime startTime;
  private String eventUrl;
  private String artistUrl;
  private String sourceEventUrl;
  private String artist;
  private String title;
  private String artistTitle;
  private String notice;
  private String content;
  private String type;
  private String subType;
  private Float price;

  public Event() {

  }

  public Event(EventRepeated event, LocalDateTime dateTime) {
    this.startTime = dateTime;
    this.artist = event.getArtist();
    this.location = event.getLocation();
    this.title = event.getTitle();
    this.eventUrl = event.getUrl();
    this.content = event.getContent();
    this.type = event.getType();
    this.subType = event.getSubType();
    this.price = event.getPrice();
    setArtistTitle();
    setNaturalId();
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getNaturalId() {
    return naturalId;
  }
  public void setNaturalId(String naturalId) {
    this.naturalId = naturalId;
  }
  public void setNaturalId() {
    this.naturalId = startTime.toString() + ": " +
        location.replaceAll("[^\\w]", "")
        .toUpperCase(Locale.ROOT);
  }

  public String getEventUrl() {
    return eventUrl;
  }

  public void setEventUrl(String url) {
    this.eventUrl = url;
  }

  public boolean hasEventUrl() {
    return eventUrl!=null && !eventUrl.isEmpty();
  }


  public String getArtistUrl() {
    return artistUrl;
  }

  public void setArtistUrl(String artistUrl) {
    this.artistUrl = artistUrl;
  }

  public boolean hasArtistUrl() {
    return artistUrl!=null && !artistUrl.isEmpty();
  }

  public String getSourceEventUrl() {
    return sourceEventUrl;
  }

  public void setSourceEventUrl(String sourceDetailsUrl) {
    this.sourceEventUrl = sourceDetailsUrl;
  }

  public boolean hasSourceEventUrl() {
    return sourceEventUrl!=null && !sourceEventUrl.isEmpty();
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public boolean hasLocation() {
    return location !=null && !location.isEmpty();
  }

  public LocalDateTime getStartTime() {
    return startTime;
  }

  public boolean hasStartTime() {
    return startTime != null;
  }

  public void setStartTime(LocalDateTime startTime) {
    this.startTime = startTime;
  }

  public String getArtist() {
    return artist;
  }

  public void setArtist(String artist) {
    this.artist = artist;
  }

  public boolean hasArtist()  {
    return artist!=null && !artist.isEmpty();
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public boolean hasTitle()  {
    return title!=null && !title.isEmpty();
  }

  public String getArtistTitle() {
    return artistTitle;
  }

  public void setArtistTitle(String artistTitle) {
    this.artistTitle = artistTitle;
  }
  public void setArtistTitle() {
    if (hasArtist() && hasTitle()) {
      this.artistTitle = artist + ": " + title;
    }
    else if (hasArtist()) {
      this.artistTitle = artist;
    }
    else if (hasTitle()) {
      this.artistTitle = title;
    }
  }

  public String getNotice() {
    return notice;
  }

  public void setNotice(String notice) {
    this.notice = notice;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public Float getPrice() {
    return price;
  }

  public void setPrice(Float price) {
    this.price = price;
  }

  public String getType() {
    return type;
  }

  public Event setType(String type) {
    this.type = type;
    return this;
  }

  public String getSubType() {
    return subType;
  }

  public void setSubType(String subType) {
    this.subType = subType;
  }

  public void prepare() {
    this.location = strip(location);
    this.artist = strip(artist);
    setArtistTitle();
    this.subType = strip(subType);
    this.type = strip(type);
    setNaturalId();
  }

  public String fetchStartTimeAsString() {
    return startTime!=null?startTime.toString(): "";
  }

  public String fetchEventUrl() {
    return eventUrl!=null?eventUrl: "";
  }
  public void upperLocation(String location) {
    this.location = upper(location);
  }
  public void upperLocation() {
    this.location = upper(this.location);
  }
  public String upper(String location) {
    location = strip(location);
    return StringUpperFirstCharCall.upperWords(location);
  }
  public void stripNotice(String content) {
    this.notice = strip(content);
  }
  public void stripArtist(String content) {
    this.artist = strip(artist);
  }
  public void stripLocation(String content) {
    this.location = strip(content);
  }

  public void setTitleStripped(String artist) {
    this.title = strip(title);
  }

  public void stripContent(String content) {
    this.content = strip(content);
  }
  public void stripType(String content) {
    this.type = strip(content);
  }
  public void stripSubType(String content) {
    this.subType = strip(content);
  }


  public String fetchTitle() {
    return title != null ? title : "";
  }
  public String fetchArtist() {
    return artist != null ? artist : "";
  }
  public String fetchType() {
    return type != null ? type : "";
  }
  public String fetchSubType() {
    return subType != null ? subType : "";
  }

  public String toString() {
    return
        naturalId + ";" +
        getArtistTitle() + ";" +
        type + "/" +
        subType + ";" +
        location + ";" +
        fetchStartTimeAsString() + ";" +
        fetchEventUrl();
  }
}
