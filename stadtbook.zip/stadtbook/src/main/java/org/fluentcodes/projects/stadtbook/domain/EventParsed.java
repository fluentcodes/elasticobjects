package org.fluentcodes.projects.stadtbook.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EventParsed extends Event {
  private List<String> otherUrls = new ArrayList<>();
  private String source;
  private String sourceLocationUrl;
  private String sourceParseUrl;
  private String sourceTicketUrl;
  private String locationUrl;
  private Boolean original;
  private Boolean persist;

  public EventParsed() {
      super();
  }
  public EventParsed(EventRepeated event, LocalDateTime dateTime) {
    super(event, dateTime);
    original = true;
    persist = true;
  }

  public Boolean getOriginal() {
    return original;
  }

  public void setOriginal(Boolean original) {
    this.original = original;
  }

  public Boolean getPersist() {
    return persist;
  }

  public void setPersist(Boolean persist) {
    this.persist = persist;
  }

  public List<String> getOtherUrls() {
    return otherUrls;
  }

  public void setOtherUrls(List<String> otherUrls) {
    this.otherUrls = otherUrls;
  }

  public void addOtherUrl(String url) {
    otherUrls.add(url);
  }

  public String getSourceLocationUrl() {
    return sourceLocationUrl;
  }

  public boolean hasSourceLocationUrl() {
    return sourceLocationUrl!=null && ! sourceLocationUrl.isEmpty();
  }

  public void setSourceLocationUrl(String sourceLocationUrl) {
    this.sourceLocationUrl = sourceLocationUrl;
  }


  public String getSourceParseUrl() {
    return sourceParseUrl;
  }

  public void setSourceParseUrl(String sourceParseUrl) {
    this.sourceParseUrl = sourceParseUrl;
  }

  public String getSourceTicketUrl() {
    return sourceTicketUrl;
  }

  public void setSourceTicketUrl(String sourceTicketUrl) {
    this.sourceTicketUrl = sourceTicketUrl;
  }

  public String getLocationUrl() {
    return locationUrl;
  }

  public void setLocationUrl(String locationUrl) {
    this.locationUrl = locationUrl;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public void prepare() {
    super.prepare();
  }

  public String fetchFirstOtherUrl() {
    return otherUrls.isEmpty() ? "" : otherUrls.get(0);
  }
  public String fetchSourceParseUrl() {
    return sourceParseUrl != null ? sourceParseUrl : "";
  }

  public String toString() {
    return super.toString() +
        fetchFirstOtherUrl() + ";" +
        fetchSourceParseUrl();


  }
}
