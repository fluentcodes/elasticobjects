package org.fluentcodes.projects.stadtbook.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EventRepeated extends Event {
  private LocalDate startDate;
  private LocalDate stopDate;
  private String repetition;
  private String url;


  public LocalDate getStartDate() {
    return startDate;
  }

  public void setStartDate(LocalDate startDate) {
    this.startDate = startDate;
  }

  public LocalDate getStopDate() {
    return stopDate;
  }

  public void setStopDate(LocalDate stopDate) {
    this.stopDate = stopDate;
  }

  public LocalDate deriveStopDate(LocalDate date) {
    if (stopDate == null) {
      return date;
    }
    if (date == null) {
      return stopDate;
    }
    if (stopDate.isBefore(date)) {
      return stopDate;
    }
    return date;
  }

  public LocalDate deriveStartDate(LocalDate date) {
    if (startDate == null) {
      return date;
    }
    if (date == null) {
      return startDate;
    }
    if (date.isBefore(startDate)) {
      return startDate;
    }
    return date;
  }

  public String getRepetition() {
    return repetition;
  }

  public void setRepetition(String repetition) {
    this.repetition = repetition;
  }

  public boolean hasRepetition() {
    return repetition!=null && !repetition.isEmpty();
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public boolean hasUrl() {
    return url!=null && !url.isEmpty();
  }

  public String toString() {
    return fetchStartTimeAsString() +
        stopDate.toString() + ";" +
        repetition + ";" +
        super.toString();
  }
}
