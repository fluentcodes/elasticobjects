package org.fluentcodes.projects.stadtbook.domain;

/**
 * https://schema.org/PostalAddress
 */
public class Location extends ContactPoint {
  private String location;
  private String streetAddress;
  private String addressCountry;
  private String addressRegion;
  private String addressLocality;
  private String town;
  private String postalCode;
  private String telephone;
  private String fax;
  private String email;
  private String url;

  public Location() {

  }
  public Location(final String location) {
    this.location = location;
  }

  public String getLocation() {
    return location;
  }


  public void setLocation(String location) {
    this.location = location;
  }

  public String getStreetAddress() {
    return streetAddress;
  }

  public void setStreetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
  }

  public String getTown() {
    return town;
  }

  public void setTown(String town) {
    this.town = town;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public String getTelephone() {
    return telephone;
  }

  public void setTelephone(String telephone) {
    this.telephone = telephone;
  }

  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String toString() {
    return location + ";" +
        streetAddress + ";" +
        postalCode + ";" +
        town + ";" +
        url + ";" +
        telephone + ";" +
        fax;
  }
}
