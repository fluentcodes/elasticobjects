package org.fluentcodes.projects.stadtbook.domain;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum Locations {
  FESTIVALS("Lustspielhaus", Arrays.asList("Lustspielhaus"), true);
  private static Map<String, Locations> typesMap;
  private List<String> synonyms;
  private String type;
  private boolean skip;
  Locations(String type, List<String> synonyms, boolean skip) {
    this.type = type;
    this.synonyms = synonyms;
    this.skip = skip;
  }

  public String getDefault() {
    return type;
  }

  private static void initTypeMap() {
    if (typesMap == null) {
      typesMap = new HashMap<>();
      for (Locations type: values()) {
        for (String synonym: type.synonyms) {
          typesMap.put(synonym, type);
        }
      }
    }
  }
  public static String getDefault(String type) {
    initTypeMap();
    if (!typesMap.containsKey(type)) {
      return type;
    }
    return typesMap.get(type).getDefault();
  }

  public static boolean skip(String type) {
    initTypeMap();
    if (!typesMap.containsKey(type)) {
      return false;
    }
    return typesMap.get(type).skip;
  }

  public static boolean hasSynonym(String type) {
    initTypeMap();
    return typesMap.containsKey(type);
  }
}
