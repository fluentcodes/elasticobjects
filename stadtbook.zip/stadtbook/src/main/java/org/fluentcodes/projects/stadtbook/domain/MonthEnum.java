package org.fluentcodes.projects.stadtbook.domain;

import java.time.Month;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;

public enum MonthEnum {
  JANUAR("Januar", Arrays.asList("Jan"), Month.JANUARY),
  FEBRUAR("Februar", Arrays.asList("Feb","Feb"), Month.FEBRUARY),
  MÄRZ("März", Arrays.asList("Mär"), Month.MARCH),
  APRIL("April", Arrays.asList("Apr"), Month.APRIL),
  MAI("Mai", Arrays.asList("Mai"), Month.MAY),
  JUNE("Juni", Arrays.asList("Jun"), Month.JUNE),
  JULY("Juli", Arrays.asList("Jul"), Month.JULY),
  AUGUST("August", Arrays.asList("Aug"), Month.AUGUST),
  SEPTEMBER("September", Arrays.asList("Sep"), Month.SEPTEMBER),
  OKTOBER("Oktober", Arrays.asList("Okt"), Month.OCTOBER),
  NOVEMBER("November", Arrays.asList("Nov"), Month.NOVEMBER),
  DEZEMBER("Dezember", Arrays.asList("Dez"), Month.DECEMBER);

  private static Map<String, MonthEnum> monthMap;
  private List<String> synonyms;
  private String defaultValue;
  private Month month;
  MonthEnum(String type, List<String> synonyms, Month month) {
    this.defaultValue = type;
    this.synonyms = synonyms;
    this.month = month;
  }

  public String getDefault() {
    return defaultValue;
  }

  private static void initMonthMap() {
    if (monthMap == null) {
      monthMap = new HashMap<>();
      for (MonthEnum type: values()) {
        monthMap.put(type.defaultValue, type);
        for (String synonym: type.synonyms) {
          monthMap.put(synonym, type);
        }
      }
    }
  }
  public static String getDefault(String month) {
    initMonthMap();
    if (!monthMap.containsKey(month)) {
      return month;
    }
    return monthMap.get(month).getDefault();
  }

  public static int getInt(String month) {
    initMonthMap();
    if (!monthMap.containsKey(month)) {
      throw new EoException("Could not find month " + month);
    }
    return monthMap.get(month).month.ordinal() + 1;
  }

  public static boolean hasSynonym(String month) {
    initMonthMap();
    return monthMap.containsKey(month);
  }
}
