package org.fluentcodes.projects.stadtbook.domain;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum Types {
  FESTIVALS("Festivals", Arrays.asList("Tollwood", "Opernfestspiele", "Festspiele")),
  SONSTIGE("Sonstige", Arrays.asList("Freizeit", "Dies und Das", "Aktivität", "Performances", "Diverses", "100 Prozent offen", "Ständige Veranstaltungen", "Stadtbibliotheken")),
  THEATER("Theater", Arrays.asList("Privattheater", "Boulevard / Komödie", "Bühne")),
  KINDER("Kinder", Arrays.asList("Kindertheater")),
  KONZERTE("Konzerte", Arrays.asList("Klassik", "Musik-Festspiele", "Musik")),
  PARTY("Party", Arrays.asList("Tanzen")),
  SPORT("Sport", Arrays.asList()),
  MAERKTE("Märkte", Arrays.asList("Messen / Märkte", "Flohmärkte","Flohmarkt"));
  static Map<String, Types> typesMap;
  List<String> synonyms;
  String type;
  Types(String type, List<String> synonyms) {
    this.type = type;
    this.synonyms = synonyms;
  }

  public String getDefault() {
    return type;
  }

  private static void initTypeMap() {
    if (typesMap == null) {
      typesMap = new HashMap<>();
      for (Types type: values()) {
        for (String synonym: type.synonyms) {
          typesMap.put(synonym, type);
        }
      }
    }
  }
  public static String getDefault(String type) {
    initTypeMap();
    if (!typesMap.containsKey(type)) {
      return type;
    }
    return typesMap.get(type).getDefault();
  }

  public static boolean hasSynonym(String type) {
    initTypeMap();
    return typesMap.containsKey(type);
  }
}
