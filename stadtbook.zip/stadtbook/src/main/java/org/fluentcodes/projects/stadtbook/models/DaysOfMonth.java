package org.fluentcodes.projects.stadtbook.models;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.fluentcodes.projects.stadtbook.calls.EventCall;
import org.fluentcodes.projects.stadtbook.domain.DayCount;

public class DaysOfMonth {
  Month month;
  Map<LocalDate, Long> dayMap;

  public DaysOfMonth(int year, Month month) {
    this.month = month;
    dayMap = new TreeMap<>();
    LocalDate firstOfMonth = LocalDate.of(year, month,1);
    while (firstOfMonth.getDayOfWeek()!= DayOfWeek.MONDAY) {
      firstOfMonth = firstOfMonth.minusDays(1);
    }
    Month nextMonth = month.plus(1);
    while (!(firstOfMonth.getDayOfWeek() == DayOfWeek.MONDAY && firstOfMonth.getMonth()==nextMonth)) {
      dayMap.put(firstOfMonth, -1L);
      firstOfMonth = firstOfMonth.plusDays(1);
    }
  }

  public DaysOfMonth(int year, Month month, List<Map<String,Object>> values) {
    this(year, month);
    for (Map<String, Object> value: values) {
      DayCount dayCount = new DayCount(value);
      LocalDate date = dayCount.getDay().toLocalDate();
      if (dayMap.containsKey(date)) {
        dayMap.put(date, dayCount.getCount());
      }
    }
  }

  public int size() {
    return dayMap.size();
  }

  public String toHtml() {
    StringBuffer html = new StringBuffer("<table>");
    for (Map.Entry<LocalDate, Long> entry: dayMap.entrySet()) {
      LocalDate date = entry.getKey();
      if (date.getDayOfWeek() == DayOfWeek.MONDAY) {
        html.append("\n  <tr>");
      }
      html.append("\n    <td>");

      if (entry.getValue()>0) {
        html.append("<a href=\"../" +
          EventCall.deriveDateName(date)   + ".html\"" +
            " target=\"_top\" " +
            " id=\"" + EventCall.deriveDateName(date) + "\">");
      }
      html.append(entry.getKey().getDayOfMonth());
      if (entry.getValue()>0) {
        html.append("</a>");
      }

      html.append("</td>");
      if (entry.getKey().getDayOfWeek() == DayOfWeek.SUNDAY) {
        html.append("\n  </tr>");
      }
    }
    html.append("\n</table>");
    return html.toString();
  }
}
