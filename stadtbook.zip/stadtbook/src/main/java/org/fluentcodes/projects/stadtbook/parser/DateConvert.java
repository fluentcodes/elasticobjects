package org.fluentcodes.projects.stadtbook.parser;

import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.elasticobjects.exceptions.EoException;

public class DateConvert {
  private Pattern pattern;
  private int[] order;
  public DateConvert(String pattern) {
    this(pattern, new int[]{1,2,3,4,5,6});
  }
  public DateConvert(String pattern, int[] order) {
    this.pattern = Pattern.compile(pattern);
    this.order = order;
  }
  public LocalDateTime parse(final String toparse) {
    Matcher datePattern = pattern.matcher(toparse);
    if (datePattern.find()) {
      int day = Integer.parseInt(datePattern.group(order[0]));
      int month = Integer.parseInt(datePattern.group(order[1]));
      int year = Integer.parseInt(datePattern.group(order[2]));
      int hour = order.length>3? Integer.parseInt(datePattern.group(order[3])):0;
      int min = order.length>4?Integer.parseInt(datePattern.group(order[4])):0;
      return LocalDateTime.of(year, month, day, hour, min);
    }
    throw new EoException("Could not parse " + toparse + " for " + pattern.toString());
  }
}
