package org.fluentcodes.projects.stadtbook.parser;

import java.time.Month;
import java.util.HashMap;
import java.util.Map;

public enum MonthConversion {
  JANUARY(Month.JANUARY, "Januar"),
  FEBRUARY(Month.FEBRUARY, "Februar"),
  MARCH(Month.MARCH, "März"),
  APRIL(Month.APRIL, "April"),
  MAY(Month.MAY, "Mai"),
  JUNE(Month.JUNE, "Juni"),
  JULY(Month.JULY, "Juli"),
  AUGUST(Month.AUGUST, "August"),
  SEPTEMBER(Month.SEPTEMBER, "September"),
  OCTOBER(Month.OCTOBER, "Oktober"),
  NOVEMBER(Month.NOVEMBER, "November"),
  DECEMBER(Month.DECEMBER, "Dezember");
  Month month;
  String german;
  static Map<String, MonthConversion> GERMAN_MAP;

  MonthConversion(Month month, String german) {
    this.month = month;
    this.german = german;
  }
  public static MonthConversion findGerman(String value) {
    if (GERMAN_MAP == null) {
      GERMAN_MAP = new HashMap<>();
      for (MonthConversion month: values()) {
        GERMAN_MAP.put(month.german, month);
      }
    }
    return GERMAN_MAP.get(value);
  }
}
