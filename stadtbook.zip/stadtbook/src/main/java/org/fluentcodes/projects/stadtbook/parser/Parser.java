package org.fluentcodes.projects.stadtbook.parser;

import java.util.Arrays;
import java.util.List;

public interface Parser {
  public static final List<String> COL_KEYS = Arrays.asList("startTime",
      "artist",
      "title",
      "artistTitle",
      "notice",
      "location",
      "type",
      "subType",
      "content",
      "price",
      "eventUrl",
      "artistUrl",
      "locationUrl",
      "sourceParseUrl",
      "sourceEventUrl",
      "sourceLocationUrl",
      "sourceTicketUrl",
      "otherUrls");
}
