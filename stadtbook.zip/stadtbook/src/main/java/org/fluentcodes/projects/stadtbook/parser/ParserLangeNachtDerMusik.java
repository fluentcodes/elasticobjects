package org.fluentcodes.projects.stadtbook.parser;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ParserLangeNachtDerMusik extends ParserFirefox implements Parser {
  private static Pattern PATTERN_TIME = Pattern.compile("(\\d\\d):(\\d\\d)");
  public ParserLangeNachtDerMusik() {
    super();
  }
  public ParserLangeNachtDerMusik(boolean test) {
    super(test);
  }

  public List<EventParsed> parse(String url) {
    List<EventParsed> events = new ArrayList<>();
    getDriver().get(url);
    List<WebElement> links = getDriver().findElements(new By.ByClassName("eventlist__entry"));
    boolean flag = false;

    for (WebElement element : links) {
      try {
        events.add(parseElement(element));
      }
      catch(Exception e) {
        System.out.println(e.getMessage());
      }
      if (isTest()) {
        break;
      }
    }
    getDriver().close();
    return events;
  }

  private EventParsed parseElement(WebElement element) {
    EventParsed event = new EventParsed();
    WebElement artistLink = element.findElement(new By.ByClassName("eventlist__event-title"))
        .findElement(new By.ByTagName("a"));
    event.addOtherUrl(artistLink.getAttribute("href"));
    event.setArtist(artistLink.getText());
    System.out.println("- " + artistLink.getText());

    // artist url
    WebElement artistDivWebSite = element.findElement(new By.ByClassName("eventlist__event-website"));
    if (artistDivWebSite != null) {
      String artistUrl = artistDivWebSite.findElement(new By.ByTagName("a"))
          .getAttribute("href");
      if (!"http://".equals(artistUrl)) {
        event.setSourceEventUrl(artistUrl);
      }
    }
    event.setType("music");
    StringBuffer subType = new StringBuffer();
    List<WebElement> types = element.findElements(new By.ByClassName("badge-pill"));
    for (WebElement type : types) {
      subType.append(type.getText() + " ");
    }
    event.setSubType(subType.toString());

    //time
    try {
      String time = element.findElement(new By.ByClassName("event__time"))
          .getText();
      Matcher matcher = PATTERN_TIME.matcher(time);
      if (matcher.find()) {
        LocalDateTime startTime =
            LocalDateTime.of(2022, 5, 7, Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)));
        event.setStartTime(startTime);
      }
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }
    // location
    WebElement location = element.findElement(new By.ByClassName("eventlist__eventlocation-title"))
        .findElement(new By.ByTagName("a"));

    // location address
    event.setLocation(location.getText());
    WebElement locationAddress = element.findElement(new By.ByClassName("eventlist__eventlocation"))
        .findElement(new By.ByTagName("address"));
    String[] address = locationAddress.getText().split("\n");
    if (address.length==2) {
      addAddress(event, address[0], address[1]);
    }
    else if (address.length==3) {
      addAddress(event, address[1], address[2]);
    }
    else if (address.length==4) {
      addAddress(event, address[2], address[3]);
    }
    else {
      //event.getLocation().setStreet(locationAddress.getText());
    }
    return event;
  }

  public void addAddress(EventParsed event, String street, String plzTown) {
    /*event.getLocation().setStreet(street);
    String[] plzTownArray = plzTown.split(" ");
    event.getLocation().setPlz(plzTownArray[0]);
    event.getLocation().setTown(plzTownArray[1]);*/
  }
}
