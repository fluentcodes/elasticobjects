package org.fluentcodes.projects.stadtbook.service;

import static org.fluentcodes.projects.stadtbook.service.DayService.TEMPLATE_DIR;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.files.DirectoryWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.templates.TemplateDirResourceCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.models.DaysOfMonth;

public class CalenderService {

  public static final String MONTH_DIR = "MonthDir";
  public static final String DATES = "dates";

  public static void createCalenderMonths(String dbHostKey, int year) {
    LocalDate now = LocalDate.now();
    if (now.getYear() != year) {
      now = LocalDate.of(year, Month.JANUARY, 1);
    }
    persistCalender(dbHostKey, now);
    Month startMonth = now.getMonth().plus(1);
    while (startMonth != Month.JANUARY) {
      now = LocalDate.of(year, startMonth, 1);
      persistCalender(dbHostKey, now);
      startMonth = now.getMonth().plus(1);
    }
  }

  static void persistCalender(String dbHostKey, LocalDate startDate) {
    EoRoot eo = readCalenderFromDb(dbHostKey, startDate);
    DaysOfMonth daysOfMonth = new DaysOfMonth(startDate.getYear(), startDate.getMonth(), (List)eo.get(DATES));

    eo.set(daysOfMonth.toHtml(), "calender");
    eo.set(startDate.getMonth().toString(), "month");
    eo.set("M&uuml;nchen", "town");

    String fileNameTemplate = "Calender.tpl";

    TemplateDirResourceCall call = new TemplateDirResourceCall(TEMPLATE_DIR, fileNameTemplate);
    String content = call.execute(eo);

    String fileNameHtml = "" + startDate.getYear() + startDate.getMonth() + ".html";
    DirectoryWriteCall writeCall = new DirectoryWriteCall(MONTH_DIR, fileNameHtml);
    writeCall.setContent(content);
    System.out.println(writeCall.execute(eo));
  }

  static EoRoot readCalenderFromDb(String dbHostKey, LocalDate startTime) {
    LocalDate monthAfter = startTime.plusMonths(1);
    LocalDate stopTime = LocalDate.of(monthAfter.getYear(), monthAfter.getMonth(), 1);

    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(startTime);
    conditionList.add(stopTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(dbHostKey, "EventCountByDate");
    call.setTargetPath("/(List)" + DATES);
    call.execute(eo);
    return eo;
  }
}
