package org.fluentcodes.projects.stadtbook.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.files.DirectoryWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.templates.TemplateDirResourceCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;

public class DayService {
  public static final String TARGET_DIR = "src/main/resources/events/";
  public static final String TEMPLATE_DIR = "TemplateDir";
  public static final String DAY_TARGET_DIR = "DayTargetDir";

  public static void persistDays(String dbHostKey, LocalDate startDate, LocalDate stopDate) {
    if (startDate.compareTo(LocalDate.now())<0) {
      startDate = LocalDate.now();
    }
    if (stopDate.compareTo(startDate)<0) {
      stopDate = startDate.plusDays(1);
    }
    while (stopDate.compareTo(startDate)>0) {
      persistDay(dbHostKey, startDate);
      startDate = startDate.plusDays(1);
    }
  }

  static EoRoot readDayFromDb(String dbHostKey, LocalDate startTime) {
    LocalDate stopTime = startTime.plusDays(1);
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(startTime);
    conditionList.add(stopTime);
    eo.set(conditionList, "conditionList");
    DbSqlReadCall call = new DbSqlReadCall(dbHostKey, "EventInDateInterval");
    call.setTargetPath("/(List,Event)dates");
    call.getListParams().setRowEnd(10000);
    call.execute(eo);
    return eo;
  }

  static String createEventsHtml(EoRoot eo, LocalDate startTime) {
    StringBuilder eventsDaily = new StringBuilder();
    List<Event> object = (List<Event>)eo.get("/dates");
    eventsDaily.append("<div>\n<table>\n");
    for (Event event: object) {
      eventsDaily.append("  <tr>\n");
      eventsDaily.append("     <td align=\"right\">");
      eventsDaily.append( getTime(event.getStartTime()));
      eventsDaily.append("     </td>\n");
      eventsDaily.append("     <td>");
      if (event.getEventUrl()!=null) {
        eventsDaily.append("<a href=\"" + event.getEventUrl() + "\">");
      }
      eventsDaily.append( event.getLocation());
      if (event.getEventUrl()!=null) {
        eventsDaily.append("</a>");
      }
      eventsDaily.append("     </td>\n");
      eventsDaily.append("  </tr>\n" +
          "  <tr><td></td>");
      eventsDaily.append("     <td>");
      eventsDaily.append( event.getArtistTitle());
      eventsDaily.append("     </td>\n");
      eventsDaily.append("  </tr>\n");

    }
    eventsDaily.append("</table>\n</div>\n");

    return replaceUml(eventsDaily.toString());
  }

  static String getTime(LocalDateTime localDateTime) {
    return "" + localDateTime.getHour() + ":" + getMinute(localDateTime);
  }

  static String getMinute(LocalDateTime localDate) {
    String minute = Integer.valueOf(localDate.getMinute()).toString();
    return minute.length()==1? "0" + minute:minute;
  }

  static String replaceUml(String input) {
    return input
        .replaceAll("ß","&szlig;")
        .replaceAll("Ä","&Auml;")
        .replaceAll("Ü","&Uuml;")
        .replaceAll("Ö","&Ouml;")
        .replaceAll("ö","&ouml;")
        .replaceAll("ä","&auml;")
        .replaceAll("ü","&uuml;");
  }

  static String createMonthIframe(LocalDate date) {
    StringBuilder monthNav = new StringBuilder();
    monthNav.append("<td>\n" +
        "         <iframe src=\"months/" + date.getYear() + date.getMonth() + ".html\"></iframe>\n" +
        "       </td>");
    return monthNav.toString();
  }

  static String createMonthNav(LocalDate date) {
    StringBuilder calenderNav = new StringBuilder();
    calenderNav.append("    <table class=\"calender-frame\">     <tr>");
    if (date.getMonth().getValue()>LocalDate.now().getMonth().getValue()) {
      LocalDate previousMonth = date.minusMonths(1);
      calenderNav.append(createMonthIframe(previousMonth));
    }
    calenderNav.append(createMonthIframe(date));
    calenderNav.append(createMonthIframe(date.plusMonths(1)));
    calenderNav.append("      </tr>" +
            "    </table>");
    return calenderNav.toString();
  }

  public static void persistDay(String dbHostKey, LocalDate startDate) {
    EoRoot eo = readDayFromDb(dbHostKey, startDate);
    eo.set(createEventsHtml(eo, startDate),"events");
    eo.set(startDate.getDayOfMonth() + ". " + startDate.getMonth().getValue() + ". " + startDate.getYear(), "day");
    eo.set("M&uuml;nchen", "town");
    eo.set(createMonthNav(startDate), "monthNav");

    String fileNameTemplate = "Day.tpl";
    TemplateDirResourceCall call = new TemplateDirResourceCall(TEMPLATE_DIR, fileNameTemplate);
    String content = call.execute(eo);

    String fileNameHtml = "" + startDate.getYear() + startDate.getMonth() + startDate.getDayOfMonth() + ".html";
    DirectoryWriteCall writeCall = new DirectoryWriteCall(DAY_TARGET_DIR, fileNameHtml);
    writeCall.setContent(content);
    System.out.println(writeCall.execute(eo));
  }
}
