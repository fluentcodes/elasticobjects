package org.fluentcodes.projects.stadtbook.service;

import static org.fluentcodes.projects.stadtbook.MainParser.MAPPER;
import static org.fluentcodes.projects.stadtbook.parser.Parser.COL_KEYS;

import com.fasterxml.jackson.databind.JavaType;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxReadCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;

public class EventService {
  public static String RESOURCES = "src/main/resources";

  public static EoRoot readEoXlsx(final String fileName) {
    EoRoot eo = ObjectProvider.createEoWithClasses(List.class, Event.class);
    XlsxReadCall call = new XlsxReadCall("InputDir", fileName);
    call.getListParams().setRowHead(0);
    call.setModelConfigKey(Event.class.getSimpleName());
    call.execute(eo);
    return eo;
  }
  public static List<Event> readXlsx(final String fileName) {
    return (List<Event>)readEoXlsx(fileName).get();
  }


  public static List<Event> readFile(File file) throws IOException {
    JavaType itemType = MAPPER.getTypeFactory().constructCollectionType(List.class, EventParsed.class);
    return MAPPER.readValue(file, itemType);
  }

  public static void persistEventParsedXlsx(final String fileName, final List<EventParsed> events) {
    EO eo = ObjectProvider.createEo(events);
    XlsxWriteCall call = new XlsxWriteCall("InputDir", fileName);
    call.getListParams().setRowHead(0);
    call.setColKeys(COL_KEYS);
    System.out.println(call.execute(eo));
  }
}
