let stadtbook = {};

stadtbook.readAnchors = function() {
    stadtbook.anchors = JSON.parse(localStorage.getItem('stadtbookAnchorIds'));
}

stadtbook.storeAnchors = function() {
    localStorage.setItem('stadtbookAnchorIds', JSON.stringify(stadtbook.anchors));
}

stadtbook.clearAnchors = function() {
    localStorage.setItem('stadtbookAnchorIds', null);
}

stadtbook.initAnchors = function() {
    stadtbook.anchors = {
        "Führungen":{"id":false},
        "Galerien":{"id":false},
        "Kabarett":{"id":true},
        "Kinder":{"id":false},
        "Konzerte":{"id":true},
        "Literatur":{"id":false},
        "Museen":{"id":false},
        "Märkte":{"id":true},
        "Party":{"id":true},
        "Sonstige":{"id":false},
        "Sport":{"id":true},
        "Theater":{"id":false},
        "Links":{"id":false}
        };
        stadtbook.storeAnchors();
}


stadtbook.hide = function(type, toggle) {
    let anchor = stadtbook.anchors[type];
    if (anchor == undefined) {
        return;
    }
    if (anchor.id && toggle==undefined) {
        return;
    }
    var collapsable = document.getElementById('Events-' + type);

    if (collapsable == undefined) {
        console.log('Could not find Event-' + type);
        return;
    }
    collapsable.style.display = 'none';
    // change image
    if (toggle == undefined) {
        return;
    }
    var collapsableImage = document.getElementById('Img-' + type);
    if (collapsableImage == undefined) {
        console.log('Could not find Img-' + type);
        return;
    }
    collapsableImage.innerHTML = '&#x2795;';
}


stadtbook.show = function(type, toggle) {
    let anchor = stadtbook.anchors[type];
    if (anchor == undefined) {
        return;
    }
    var collapsable = document.getElementById('Events-' + type);
    if (collapsable == undefined) {
        console.log('Could not find Event-' + type);
        return;
    }
    collapsable.style.display = 'block';
    if (toggle == undefined) {
        return;
    }
    var collapsableImage = document.getElementById('Img-' + type);
    if (collapsableImage == undefined) {
        console.log('Could not find Img-' + type);
        return;
    }
    collapsableImage.innerHTML = '&#x2796;';
}
stadtbook.flagAndShow = function(type) {
        let anchor = stadtbook.anchors[type];
        if (anchor == undefined) {
            return;
        }
        anchor.id = !anchor.id;
        if (anchor.id) {
            stadtbook.show(type, true);
        }
        else {
            stadtbook.hide(type, true);
        }
        stadtbook.storeAnchors();
}

stadtbook.init = function(clean) {
    if (clean == undefined || clean != '?clear') {
        stadtbook.readAnchors();
    }
    else {
        initAnchors
    }

    for (var anchor in stadtbook.anchors) {
        let show = stadtbook.anchors[anchor].id;
        if (show) {
            stadtbook.show(anchor, true);
        }
        else {
            stadtbook.hide(anchor, true);
        }
    }
}
