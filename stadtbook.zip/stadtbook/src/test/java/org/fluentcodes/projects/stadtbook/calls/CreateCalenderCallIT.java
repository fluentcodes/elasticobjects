package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.Month;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;

public class CreateCalenderCallIT {


  @Test
  public void persistCalenderMonth() {
    EoRoot eo = ObjectProvider.createEo();
    LocalDate startDate = LocalDate.of(2022, Month.JUNE, 2);
    //LocalDate endDate = startDate.plusMonths(1);
    LocalDate endDate = startDate.plusYears(1);
    CreateCalenderCall call = new CreateCalenderCall();
    call.setStartDate(startDate);
    call.setStopDate(endDate);
    call.execute(eo);
  }
}
