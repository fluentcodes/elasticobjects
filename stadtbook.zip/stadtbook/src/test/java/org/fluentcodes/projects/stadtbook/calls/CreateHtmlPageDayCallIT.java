package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;

public class CreateHtmlPageDayCallIT {

  @Test
  public void persistDays() {
    EoRoot eo = ObjectProvider.createEo();
    LocalDate startDate = LocalDate.of(2022, 6, 1);
    LocalDate endDate = startDate.plusMonths(3);
    //LocalDate endDate = startDate.plusDays(1);
    CreateHtmlPageDayCall call = new CreateHtmlPageDayCall();
    call.setStartDate(startDate);
    call.setStopDate(endDate);
    call.execute(eo);
  }
}
