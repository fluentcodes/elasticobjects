package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.EventDbFileInitIT.DB_MODELS_H2_FILE;
import static org.fluentcodes.projects.stadtbook.calls.EventDbFileInitIT.HOST_H2_FILE;
import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelReadCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventFactory;
import org.junit.jupiter.api.Test;

public class DbModelReadCallEventIT {

  @Test
  public void executeDbModelReadCall_type_Kabarett() {
    DbModelReadCall readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    EO root = ObjectProvider.createEo();
    Event event = new Event().setType("Kabarett");
    EOInterfaceScalar findEo = root.set( event, "find");
    readCall.setTargetPath("/(List,Event)queryResult");
    findEo.set("Kabarett", "type");
    readCall.execute(findEo);

    assertEquals(7, ((EO)root.getEo("queryResult")).size());
  }

  @Test
  public void executeDbSqlReadCall() {
    EoRoot eo = ObjectProvider.createEo();
    DbSqlReadCall readCall = new DbSqlReadCall(HOST_H2_FILE, "Events");
    readCall.setTargetPath("/");
    readCall.execute(eo);
    Assertions.assertThat(eo.size()).isEqualTo(57);
  }

  @Test
  public void executeDbModelReadCall_artistTest() {
    EoRoot eo = ObjectProvider.createEo(Event.class);
    eo.set("test", "artist");
    Call readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    readCall.execute(eo);
    assertEquals("url", eo.get("url"));
  }

  @Test
  public void executeDbModelReadCall_artistEoTest() {
    EO eo = EventFactory.createArtistEo();
    Call readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    readCall.execute(eo);
    assertEquals("https://www.lustspielhaus.de/kuenstler/programm/4693", eo.get("url"));
  }

  @Test
  public void runDbSqlReadCall_EventInDateInterval_true() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,05,12,10,10);
    conditionList.add(startTime);
    LocalDateTime endTime = LocalDateTime.now().plusDays(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventInDateInterval");
    call.execute(eo);
    assertEquals("Badesalz", eo.get("1/artist"));
    assertEquals(LocalDateTime.of(2022,05,13,20,00), eo.get("1/startTime"));
  }

  @Test
  public void runDbSqlReadCall_EventInDateInterval_true_mapEventList() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,05,12,10,10);
    conditionList.add(startTime);
    LocalDateTime endTime = LocalDateTime.now().plusDays(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventInDateInterval");
    call.setTargetPath("/events");
    call.execute(eo);
    assertEquals("Badesalz", eo.get("events/1/artist"));
    assertEquals(LocalDateTime.of(2022,05,13,20,00), eo.get("events/1/startTime"));
  }

  @Test
  public void runDbSqlReadCall_EventCountByDate_true_mapEventList() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,05,12,10,10);
    conditionList.add(startTime);
    LocalDateTime endTime = LocalDateTime.now().plusDays(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventCountByDate");
    call.setTargetPath("/dates");
    call.execute(eo);
    assertEquals(3L, eo.get("dates/0/count"));
    assertEquals(LocalDateTime.of(2022,05,13,00,00), eo.get("dates/0/eventDay"));
  }
}
