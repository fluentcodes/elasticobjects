package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.EventDbFileInitIT.HOST_H2_FILE;
import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;

public class DbSqlReadCallEventIT {

  @Test
  public void allEvents() {
    EoRoot eo = ObjectProvider.createEo();
    DbSqlReadCall readCall = new DbSqlReadCall(HOST_H2_FILE, "AllEvents");
    readCall.setTargetPath("/");
    readCall.execute(eo);
    Assertions.assertThat(eo.size()).isEqualTo(100);
  }

  @Test
  public void eventInDateInterval_true() {
    EoRoot eo = ObjectProvider.createEo();

    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,5,24,0,0);
    conditionList.add(startTime);
    LocalDateTime endTime = startTime.plusMonths(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");

    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventInDateInterval");
    call.setTargetPath("/(List,Event)events");
    call.execute(eo);
    assertEquals("Badesalz", eo.get("/events/0/artist"));
    assertEquals(LocalDateTime.of(2022,05,13,20,00), eo.get("/events/0/startTime"));
  }

  @Test
  public void eventInDateInterval_true_mapEventList() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,05,12,10,10);
    conditionList.add(startTime);
    LocalDateTime endTime = LocalDateTime.now().plusDays(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventInDateInterval");
    call.setTargetPath("/events");
    call.execute(eo);
    assertEquals("Badesalz", eo.get("events/1/artist"));
    assertEquals(LocalDateTime.of(2022,05,13,20,00), eo.get("events/1/startTime"));
  }

  @Test
  public void runDbSqlReadCall_EventCountByDate_true_mapEventList() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    LocalDateTime startTime = LocalDateTime.of(2022,05,12,10,10);
    conditionList.add(startTime);
    LocalDateTime endTime = LocalDateTime.now().plusDays(2);
    conditionList.add(endTime);
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_FILE, "EventCountByDate");
    call.setTargetPath("/dates");
    call.execute(eo);
    assertEquals(3L, eo.get("dates/0/count"));
    assertEquals(LocalDateTime.of(2022,05,13,00,00), eo.get("dates/0/eventDay"));
  }
}
