package org.fluentcodes.projects.stadtbook.calls;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.HostConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelDeleteCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelQueryCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelReadCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelsConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelsCreateCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlExecuteCall;
import org.fluentcodes.projects.elasticobjects.domain.test.AnObject;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventFactory;
import org.fluentcodes.projects.stadtbook.service.EventService;
import org.junit.jupiter.api.Test;

public class EventDbFileInitIT {
  public static final String HOST_H2_FILE = "h2:file:basic";
  public static final String DB_MODELS_H2_FILE = "h2:file";

  @Test
  public void init() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    Call call = new DbSqlExecuteCall(HOST_H2_FILE, "stadtbook-create");
    call.execute(eo);
  }

  @Test
  public void startDbModelsCreateCall() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    Call call = new DbModelsCreateCall(DB_MODELS_H2_FILE);
    call.execute(eo);
  }

  @Test
  public void executeDbModelWriteCall_Test() {
    EoRoot data = EventFactory.readEoXlsx();
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(data);
  }

  @Test
  public void executeDbModelWriteCall() {
    //EoRoot data = EventFactory.createEoTest("events:2022-05-30-2022-09-01");
    EoRoot data = EventService.readEoXlsx("MuenchenDe:2022-06-01-2022-09-01.xlsx");
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(data);
  }

  @Test
  public void executeDbModelQueryCall_type_Kabarett() {
    DbModelQueryCall queryCall = new DbModelQueryCall(DB_MODELS_H2_FILE);
    EO root = ObjectProvider.createEo();
    Event event = new Event().setType("Kabarett");
    EOInterfaceScalar findEo = root.set( event, "filter");
    queryCall.setTargetPath("/queryResult");
    queryCall.execute(findEo);

    assertEquals(10, ((EO)findEo.getEo("test")).size());
  }

  @Test
  public void test() {
    assertEquals("h2", "h2");
  }

  @Test
  public void checkHostConfigH2Mem() {
    HostConfig h2Mem = (HostConfig) ObjectProvider.CONFIG_MAPS.find(HostConfig.class, HOST_H2_FILE);
    assertEquals("h2", h2Mem.getHostName());
  }

  @Test
  public void checkDbModelConfigEvent() {
    DbModelConfig h2Mem = (DbModelConfig) ObjectProvider.CONFIG_MAPS.find(DbModelConfig.class, "Event");
    assertEquals("Event", h2Mem.getNaturalId());
  }

  @Test
  public void checkDbModelsConfigH2Mem() {
    DbModelsConfig h2Mem = (DbModelsConfig) ObjectProvider.CONFIG_MAPS.find(DbModelsConfig.class, DB_MODELS_H2_FILE);
    assertEquals(DB_MODELS_H2_FILE, h2Mem.getNaturalId());
    DbModelConfig anObjectDbModel = h2Mem.getDbModelConfig(AnObject.class);
    assertNotNull(anObjectDbModel);
    DbModelConfig eventDbModel = h2Mem.getDbModelConfig(Event.class);
    assertNotNull(eventDbModel);
  }

  @Test
  public void executeDbModelWriteCall_eventTest() {
    EO event = EventFactory.createMuellerEo();
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(event);

    EO findEo = ObjectProvider.createEo(Event.class);
    findEo.set("Michl Müller", "artist");
    DbModelReadCall readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    //readCall.setTargetPath("/test");
    readCall.execute(findEo);
    assertEquals("Verrückt nach Müller", findEo.get("title"));
    assertEquals(2L, findEo.get("id"));
  }

  @Test
  public void executeDbModelWriteCall_eventArtist() {
    EO event = EventFactory.createArtistEo();
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(event);

    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("artist", "artist");
    DbModelReadCall readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    //readCall.setTargetPath("/test");
    readCall.execute(eo);
    assertEquals("title", eo.get("title"));
  }

  @Test
  public void executeDbModelWriteCall_eventMueller2() {
    EO event = EventFactory.createMuellerEo();
    event.set( "Mueller2", "artist");
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(event);

    executeDbModelReadCall_eventMueller2();
    executeDbModelDeleteCall_eventMueller2();
  }

  public void executeDbModelReadCall_eventMueller2() {
    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("Mueller2", "artist");
    DbModelReadCall readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    readCall.execute(eo);
    assertEquals("Verrückt nach Müller", eo.get("title"));
  }

  public void executeDbModelDeleteCall_eventMueller2() {
    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("Mueller2", "artist");
    DbModelDeleteCall call = new DbModelDeleteCall(DB_MODELS_H2_FILE);
    call.execute(eo);
    assertEquals("Verrückt nach Müller", eo.get("title"));
  }

  @Test
  public void executeDbModelWriteCall_eventMueller() {
    EO event = EventFactory.createMuellerEo();
    Call writeCall = new DbModelWriteCall(DB_MODELS_H2_FILE);
    writeCall.execute(event);

    executeDbModelReadCall_eventMueller();
  }


  public void executeDbModelReadCall_eventMueller() {
    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("Michl Müller", "artist");
    DbModelReadCall readCall = new DbModelReadCall(DB_MODELS_H2_FILE);
    //readCall.setTargetPath("/test");
    readCall.execute(eo);
    assertEquals("Verrückt nach Müller", eo.get("title"));
  }
}
