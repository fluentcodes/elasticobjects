package org.fluentcodes.projects.stadtbook.calls;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.Call;
import org.fluentcodes.projects.elasticobjects.calls.HostConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelReadCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelWriteCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelsConfig;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlExecuteCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.domain.test.AnObject;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.EventFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class EventDbTest {
  public static final String HOST_H2_MEM = "h2:mem:basic";
  public static final String MODEL_H2_MEM = "h2:mem";

  @BeforeAll
  public static void init() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    Call call = new DbSqlExecuteCall(HOST_H2_MEM, "stadtbook-create");
    call.execute(eo);
  }

  @Test
  public void test() {
    assertEquals("h2", "h2");
  }

  @Test
  public void checkHostConfigH2Mem() {
    HostConfig h2Mem = (HostConfig) ObjectProvider.CONFIG_MAPS.find(HostConfig.class, HOST_H2_MEM);
    assertEquals("h2", h2Mem.getHostName());
  }

  @Test
  public void checkHostConfigH2MemBasic() {
    HostConfig h2Mem = (HostConfig) ObjectProvider.CONFIG_MAPS.find(HostConfig.class, HOST_H2_MEM);
    assertEquals("h2", h2Mem.getHostName());
  }

  @Test
  public void checkDbModelConfigEvent() {
    DbModelConfig h2Mem = (DbModelConfig) ObjectProvider.CONFIG_MAPS.find(DbModelConfig.class, "Event");
    assertEquals("Event", h2Mem.getNaturalId());
  }

  @Test
  public void checkDbModelsConfigH2Mem() {
    DbModelsConfig h2Mem = (DbModelsConfig) ObjectProvider.CONFIG_MAPS.find(DbModelsConfig.class, MODEL_H2_MEM);
    assertEquals(MODEL_H2_MEM, h2Mem.getNaturalId());
    DbModelConfig anObjectDbModel = h2Mem.getDbModelConfig(AnObject.class);
    assertNotNull(anObjectDbModel);
    DbModelConfig eventDbModel = h2Mem.getDbModelConfig(Event.class);
    assertNotNull(eventDbModel);
  }

  @Test
  public void checkDbModelsConfigH2File() {
    DbModelsConfig h2Mem = (DbModelsConfig) ObjectProvider.CONFIG_MAPS.find(DbModelsConfig.class, "h2:file");
    assertEquals("h2:file", h2Mem.getNaturalId());
  }

  @Test
  public void readCall() {
    EoRoot eo = ObjectProvider.createEoWithClasses(Event.class);
    assertNull(((Event)eo.get()).getArtist());

    Call readCall = new DbModelReadCall(MODEL_H2_MEM);
    readCall.execute(eo);
    assertEquals(Event.class, eo.get().getClass());
    assertEquals("test", eo.get("artist"));
    assertEquals("test", ((Event)eo.get()).getArtist());
  }

  @Test
  public void executeDbSqlReadCall() {
    EoRoot eo = ObjectProvider.createEo();
    DbSqlReadCall readCall = new DbSqlReadCall(MODEL_H2_MEM, "Events");
    readCall.setTargetPath("/");
    readCall.execute(eo);
    Assertions.assertThat(eo.size()).isEqualTo(1);
  }

  @Test
  public void executeDbModelReadCall_artitsTest() {
    EoRoot eo = ObjectProvider.createEo(Event.class);
    eo.set("test", "artist");
    Call readCall = new DbModelReadCall(MODEL_H2_MEM);
    readCall.execute(eo);
    assertEquals("url", eo.get("url"));
  }

  @Test
  public void executeDbModelWriteCall_eventTest() {
    EO event = EventFactory.createMuellerEo();
    Call writeCall = new DbModelWriteCall(MODEL_H2_MEM);
    writeCall.execute(event);

    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("Michl Müller", "artist");
    DbModelReadCall readCall = new DbModelReadCall(MODEL_H2_MEM);
    //readCall.setTargetPath("/test");
    readCall.execute(eo);
    assertEquals("Verrückt nach Müller", eo.get("title"));
    assertEquals(2L, eo.get("id"));
  }

  @Test
  public void executeDbModelWriteCall_eventArtist() {
    EO event = EventFactory.createArtistEo();
    Call writeCall = new DbModelWriteCall(MODEL_H2_MEM);
    writeCall.execute(event);

    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("artist", "artist");
    DbModelReadCall readCall = new DbModelReadCall(MODEL_H2_MEM);
    //readCall.setTargetPath("/test");
    readCall.execute(eo);
    assertEquals("title", eo.get("title"));
  }

  @Test
  public void executeDbModelWriteCall_eventMueller() {
    EO event = EventFactory.createMuellerEo();
    Call writeCall = new DbModelWriteCall(MODEL_H2_MEM);
    writeCall.execute(event);

    EO eo = ObjectProvider.createEo(Event.class);
    eo.set("Michl Müller", "artist");
    DbModelReadCall readCall = new DbModelReadCall(MODEL_H2_MEM);
    //readCall.setTargetPath("/test");
    readCall.execute(eo);
    assertEquals("Verrückt nach Müller", eo.get("title"));
  }

  @Test
  public void executeDbModelWriteCall_LU2205() {
    EO data = EventFactory.createLU2205JsonEO();
    Call writeCall = new DbModelWriteCall(MODEL_H2_MEM);
    writeCall.execute(data);
  }

  @Test
  public void runDbSqlReadCall_all() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    Call call = new DbSqlReadCall(HOST_H2_MEM, "Events");
    call.execute(eo);
    assertEquals("title", eo.get("0/title"));
  }

  @Test
  public void runDbSqlReadCall_eqTitle() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    eo.set("title eq title", "conditions");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "Events");
    call.execute(eo);
    assertEquals("title", eo.get("0/title"));
  }

  @Test
  public void runDbSqlReadCall_likeTitle() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    eo.set("title like tit%", "conditions");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "Events");
    call.execute(eo);
    assertEquals("title", eo.get("0/title"));
  }

  @Test
  public void runDbSqlReadCall_neTitle() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    eo.set("title ne title", "conditions");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "Events");
    call.execute(eo);
    assertFalse( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_Date() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventsDate");
    call.execute(eo);
    assertFalse( eo.hasEo("1"));
  }

  @Test
  public void runDbSqlReadCall_ConditionList_Date() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.now());
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventsDateParams");
    call.execute(eo);
    assertTrue( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_ConditionList_Date_back() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.of(2022,05,04,10,10));
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventsDateParams");
    call.execute(eo);
    assertFalse( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_EventInDateInterval_true() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.of(2022,05,04,10,10));
    conditionList.add(LocalDateTime.now().plusDays(1));
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventInDateInterval");
    call.execute(eo);
    assertTrue( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_EventInDateInterval_inFuture_false() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.now().plusDays(2));
    conditionList.add(LocalDateTime.now().plusDays(3));
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventInDateInterval");
    call.execute(eo);
    assertFalse( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_EventInDateInterval_inPast_false() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.now().minusMonths(2));
    conditionList.add(LocalDateTime.now().minusMonths(1));
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventInDateInterval");
    call.execute(eo);
    assertFalse( eo.hasEo("0"));
  }

  @Test
  public void runDbSqlReadCall_EventByDate_true() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    List<Object> conditionList = new ArrayList<>();
    conditionList.add(LocalDateTime.of(2022,05,04,10,10));
    conditionList.add(LocalDateTime.now().plusDays(1));
    eo.set(conditionList, "conditionList");
    Call call = new DbSqlReadCall(HOST_H2_MEM, "EventByDate");
    call.execute(eo);
    assertTrue( eo.hasEo("0"));
  }
}
