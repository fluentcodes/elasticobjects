package org.fluentcodes.projects.stadtbook.calls;

enum ParserAction {
  PARSE, READ_PERSIST, PARSE_PERSIST;
}
