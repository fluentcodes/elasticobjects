package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.EventCall.EVENTS_PARSED_PATH;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;

public class ParserInMuenchenCallIT {


  @Test
  public void parseAndPersist()  {
    LocalDate startDate = LocalDate.of(2022,6,1);
    LocalDate stopDate = LocalDate.of(2022,7,1);
    //LocalDate stopDate = startDate.plusDays(2);
    EventCall call = new EventParseAndPersistCall()
        .setParserCall(new ParserInMunchenCall())
        .setPersistXlsx(true)
        //.setReadXlsx(true)
        .setPersistDb(true)
        .setStartDate(startDate)
        .setStopDate(stopDate)
        .setTest(false);
    EoRoot eo = ObjectProvider.createEo();
    call.execute(eo);
    assertEquals(1, ((EoChild)eo.getEo(EVENTS_PARSED_PATH)).size());
  }

}
