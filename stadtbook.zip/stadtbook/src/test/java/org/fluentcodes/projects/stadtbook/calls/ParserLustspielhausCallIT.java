package org.fluentcodes.projects.stadtbook.calls;

import static org.fluentcodes.projects.stadtbook.calls.ParserCall.EVENTS_PARSED_PATH;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.fluentcodes.projects.elasticobjects.EoChild;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.junit.jupiter.api.Test;

public class ParserLustspielhausCallIT {
  @Test
  public void parseList()  {
    //LocalDate startDate = LocalDate.now();
    LocalDate startDate = LocalDate.of(2022,7,1);
    LocalDate stopDate = startDate.plusMonths(1);
    EventCall call = new EventParseAndPersistCall()
        .setParserCall(new ParserLustspielhausCall())
        .setPersistXlsx(true)
        //.setReadXlsx(true)
        .setPersistDb(true)
        .setStartDate(startDate)
        .setStopDate(stopDate)
        .setTest(false);
    EoRoot eo = ObjectProvider.createEo();
    call.execute(eo);
    assertEquals(1, ((EoChild)eo.getEo(EVENTS_PARSED_PATH)).size());
  }

  @Test
  public void parseAstorTest() {
    EventParsed event = new ParserLustspielhausCall().parseEvent("https://www.lustspielhaus.de/kuenstler/programm/3822");
    assertNotNull(event);
  }

  @Test
  public void parseDate() {
    String content = "<span>\n" +
        "                                Reservieren Sie jetzt für diesen Termin Ihre Karten bequem online:\n" +
        "                            </span>\n" +
        "                                        \n" +
        "                                                                                                                                                                                        <a href=\"https://eulenspiegel.muenchenticket.net/shop/136/link/event/342346\" target=\"_blank\" class=\"d-block available  odd\">\n" +
        "                                                                                                                Di, 03.05.2022 (20:00h - 30,60 €)\n" +
        "                                                    </a>";
    EventParsed event = new EventParsed();
    ParserLustspielhausCall.parseDate(event, content);
    assertEquals(LocalDateTime.of(2022,5, 3, 20,0), event.getStartTime());
    assertEquals(30.6, event.getPrice(),0.01);
  }
}
