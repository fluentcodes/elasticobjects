package org.fluentcodes.projects.stadtbook.calls;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.calls.event.CreateEventsRepeatedCall;
import org.fluentcodes.projects.stadtbook.parser.DateConvert;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserPersistCallIT {
  private static final Logger LOGGER = LoggerFactory.getLogger(ParserPersistCallIT.class);
  @Test
  public void parseRoteSonne()  {
    parseSimple(new ParserRoteSonneCall(), ParserAction.PARSE, false);
  }

@Test
public void checkDate() {
  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm z");
  LocalDateTime time = LocalDateTime.parse("2022-6-4T23:00+2:00", formatter);
}

  @Test
  public void checkDate2() {
    DateConvert converter = new DateConvert("(\\d\\d\\d\\d)-(\\d+)-(\\d+).*?(\\d\\d):(\\d\\d)", new int[]{3,2,1,4,5});
    LocalDateTime time = converter.parse("2022-6-4T23:00+2:00");
  }


  @Test
  public void parseBahnwaerterThiel()  {
    parseSimple(new ParserBahnwaerterThielCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseBackstage()  {
    parseSimple(new ParserBackstageCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseBandsInTown()  {
    parseSimple(new ParserBandsInTownCall(), ParserAction.READ_PERSIST, LocalDate.of(2022,6,1), LocalDate.of(2022,6,5), true);
  }

  @Test
  public void createEventsRepeated()  {
    parseSimple(new CreateEventsRepeatedCall(), ParserAction.PARSE, LocalDate.of(2022,6,7), LocalDate.of(2022,6,10), true);
  }

  @Test
  public void parseFeierwerk()  {
    parseSimple(new ParserFeierwerkCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseFreiheitshalle()  {
    parseSimple(new ParserFreiheitshalleCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseGansAmWasser()  {
    parseSimple(new ParserGansAmWasserCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseGansWoAnders()  {
    parseSimple(new ParserGansWoAndersCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseMilla()  {
    parseSimple(new ParserMillaCall(), ParserAction.PARSE, false);
  }


  @Test
  public void parseMuffatHalle()  {
    parseSimple(new ParserMuffatHalleCall(), ParserAction.PARSE, false);
  }

  @Test
  public void parseStrom()  {
    parseSimple(new ParserStromCall(), ParserAction.READ_PERSIST, false);
  }

  @Test
  public void parseTheatron()  {
    parseSimple(new ParserTheatronCall(), ParserAction.READ_PERSIST, false);
  }

  @Test
  public void parseTollwood()  {
    parseSimple(new ParserTollwoodCall(), ParserAction.PARSE, false);
  }

  @Test
  public void loadAll() {
    loadSimple();
    loadMonth();
    loadMuenchen();
  }

  @Test
  public void loadSimple() {
    loadSimple(new ParserBackstageCall());
    loadSimple(new ParserFeierwerkCall());
    loadSimple(new ParserFreiheitshalleCall());
    loadSimple(new ParserGansAmWasserCall());
    loadSimple(new ParserMillaCall());
    loadSimple(new ParserMuffatHalleCall());
    loadSimple(new ParserStromCall());
    loadSimple(new ParserTheatronCall());
    loadSimple(new ParserTollwoodCall());
    loadSimple(new ParserRoteSonneCall());
    loadSimple(new ParserBahnwaerterThielCall());
  }

  @Test
  public void loadMonth() {
    loadMonth(new ParserInMunchenCall(), Month.JULY);
    loadMonth(new ParserLustspielhausCall(), Month.JUNE);
    loadMonth(new ParserLustspielhausCall(), Month.JULY);
    loadMonth(new ParserInMunchenCall(), Month.JUNE);

  }

  @Test
  public void loadMuenchen() {
    parseSimple(new ParserMuenchenDeCall(), ParserAction.READ_PERSIST, LocalDate.of(2022,6,1), LocalDate.of(2022,9,1), false);
  }

  private void loadMonth(ParserCall parserCall, Month month)  {
    LocalDate startDate = LocalDate.of(2022,month,1);
    LocalDate stopDate = startDate.plusMonths(1);
    parseSimple(parserCall, ParserAction.READ_PERSIST, startDate, stopDate, false);
  }

  private void loadSimple(ParserCall parserCall)  {
    LocalDate startDate = LocalDate.of(2022,6,1);
    LocalDate stopDate = LocalDate.of(2022,7,1);
    parseSimple(parserCall, ParserAction.READ_PERSIST, startDate, stopDate, false);
  }

  private void parseSimple(ParserCall parserCall, ParserAction action, boolean test)  {
    LocalDate startDate = LocalDate.of(2022,6,1);
    LocalDate stopDate = LocalDate.of(2022,7,1);
    parseSimple(parserCall, action, startDate, stopDate, test);
  }

  private void parseSimple(ParserCall parserCall, ParserAction action, LocalDate startDate, LocalDate stopDate, boolean test)  {
    LOGGER.info(parserCall.getClass().getSimpleName() + ": " + action);
    EventParseAndPersistCall call = new EventParseAndPersistCall()
        .setParserCall(parserCall);
    if (action == ParserAction.PARSE) {
      call.setPersistXlsx(true);
    }
    else if (action == ParserAction.READ_PERSIST) {
      call
          .setReadXlsx(true)
          .setPersistDb(true);
    }
    else if (action == ParserAction.PARSE_PERSIST) {
      call
          .setPersistXlsx(true)
          .setPersistDb(true);
    }

    call
        .setStartDate(startDate)
        .setStopDate(stopDate)
        .setTest(test);
    EoRoot eo = ObjectProvider.createEo();
    call.execute(eo);
  }

  @Test
  public void parseReadPersistOnePage(ParserCall parserCall)  {
    LocalDate startDate = LocalDate.of(2022,6,1);
    LocalDate stopDate = LocalDate.of(2022,7,1);
    EventCall call = new EventParseAndPersistCall()
        .setParserCall(parserCall)
        //.setPersistXlsx(true)
        .setReadXlsx(true)
        .setPersistDb(true)
        .setStartDate(startDate)
        .setStopDate(stopDate)
        .setTest(true);
    EoRoot eo = ObjectProvider.createEo();
    call.execute(eo);
  }
}
