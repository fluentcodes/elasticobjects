package org.fluentcodes.projects.stadtbook.calls.events;


import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.fluentcodes.projects.stadtbook.calls.event.CronTabs;
import org.junit.jupiter.api.Test;

public class CronTabsTest {
  @Test
  public void test_00_0601_0605() {
    CronTabs cronTabs = new CronTabs("0 0 * * *");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 6,1),LocalDate.of(2022, 6,5));
    assertEquals(5, dateTimes.size());
  }

  @Test
  public void test_Sunday_0601_0609() {
    CronTabs cronTabs = new CronTabs("0 0 * * 7");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 6,1),LocalDate.of(2022, 6,9));
    assertEquals(1, dateTimes.size());
  }

  @Test
  public void test_June_0525_0603() {
    CronTabs cronTabs = new CronTabs("0 0 * 6 *");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 5,25),LocalDate.of(2022, 6,3));
    assertEquals(3, dateTimes.size());
  }

  @Test
  public void test_Days_25_01_0525_0603() {
    CronTabs cronTabs = new CronTabs("0 0 1,25 * *");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 5,25),LocalDate.of(2022, 6,3));
    assertEquals(2, dateTimes.size());
  }

  @Test
  public void test_0__0601() {
    CronTabs cronTabs = new CronTabs("* 0 * * *");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 6,1),LocalDate.of(2022, 6,1));
    assertEquals(60, dateTimes.size());
  }

  @Test
  public void test_Sunday_0601() {
    CronTabs cronTabs = new CronTabs("* 0 * * *");
    List<LocalDateTime> dateTimes = cronTabs.deriveDates(LocalDate.of(2022, 6,1),LocalDate.of(2022, 6,1));
    assertEquals(60, dateTimes.size());
  }
}
