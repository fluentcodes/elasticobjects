package org.fluentcodes.projects.stadtbook.calls.events;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.calls.event.EventBackupRestoreCall;
import org.fluentcodes.projects.stadtbook.calls.postaladdress.PostalAddressBackupRestoreCall;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventsBackupRestoreIT {
  private static final Logger LOGGER = LoggerFactory.getLogger(EventsBackupRestoreIT.class);

  @Test
  public void restore() {
    EOInterfaceScalar eo = ObjectProvider.createEo();
    EventBackupRestoreCall call = new EventBackupRestoreCall();
    call.execute(eo);
  }
}
