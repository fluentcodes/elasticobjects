package org.fluentcodes.projects.stadtbook.calls.postaladdress;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostalAddressBackupIT {
  private static final Logger LOGGER = LoggerFactory.getLogger(PostalAddressBackupIT.class);

  @Test
  public void backup() {
    EOInterfaceScalar eo = ObjectProvider.createEo();
    PostalAddressBackupCall call = new PostalAddressBackupCall();
    call.execute(eo);
  }
}
