package org.fluentcodes.projects.stadtbook.calls.postaladdress;

import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PostalAddressBackupRestoreIT {
  private static final Logger LOGGER = LoggerFactory.getLogger(PostalAddressBackupRestoreIT.class);

  @Test
  public void restore() {
    EOInterfaceScalar eo = ObjectProvider.createEo();
    PostalAddressBackupRestoreCall call = new PostalAddressBackupRestoreCall();
    call.execute(eo);
  }
}
