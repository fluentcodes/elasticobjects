package org.fluentcodes.projects.stadtbook.domain;

import static org.junit.Assert.assertEquals;

import java.util.List;
import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.io.IOClasspathEOFlatList;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.service.EventService;
import org.fluentcodes.tools.io.IOString;

public class EventFactory {

  public static final String TEST_XLSX = "test.xlsx";
  public static final String IN_MUENCHEN1 = "inmuenchen:2022-05-24-2022-05-25.xlsx";
  public static final String IN_MUENCHEN2 = "inmuenchen:2022-05-26-2022-07-01.xlsx";
  public static String getArtist() {
    return "{\n" +
        "  \"url\" : \"https://www.lustspielhaus.de/kuenstler/programm/4693\",\n" +
        "  \"location\" : \"Lustspielhaus\",\n" +
        "  \"startTime\" : \"2022-05-03T20:00:00\",\n" +
        "  \"artist\" : \"artist\",\n" +
        "  \"title\" : \"title\",\n" +
        "  \"type\" : \"Kabarett\",\n" +
        "  \"subType\" : null,\n" +
        "  \"price\" : 30.6\n" +
        "}";
  }

  public static EO createArtistEo() {
    EoRoot eo = ObjectProvider.createEoWithClasses(Event.class);
    return eo.map(getArtist());
  }

  public static String getMueller() {
    return "{\n" +
        "  \"otherUrls\" : [ \"https://www.youtube.com/results?search_query=Michl+Müller\" ],\n" +
        "  \"url\" : \"https://www.lustspielhaus.de/kuenstler/programm/4693\",\n" +
        "  \"location\" : \"Lustspielhaus\",\n" +
        "  \"startTime\" : \"2022-05-03T20:00:00\",\n" +
        "  \"artist\" : \"Michl Müller\",\n" +
        "  \"title\" : \"Verrückt nach Müller\",\n" +
        "  \"content\" : \"\\n                                Michl Müller, bekannt aus den TV-Quotenrennern „Fastnacht\\nin Franken“ und „Drei. Zwo. Eins. Michl Müller“, geht mit\\nseinem neuen Programm „Verrückt nach Müller“ ab März\\n2021 auf Tour.\\n<br><br>\\nFreuen Sie sich auf einen mitreißenden, authentischen\\nAbend des fränkischen Gesamtkunstwerks, der sich wieder\\neinmal leidenschaftlich zwischen Kabarett und Comedy\\nbewegt.\\n<br><br>\\nVon den kleinen Alltagsgeschichten bis hin zur großen Politik, mal als Spaßmacher, mal\\nals Kabarettist, macht das Naturtalent auch diesmal vor keinem Thema halt und es\\nsprudeln zielsicher die Pointen.\\n<br><br>\\nUnd wenn der selbsternannte „Dreggsagg“ (Fränkisch für „Schelm“) aus der Rhön, dann\\nauch noch seine herrlich schrägen Lieder anstimmt, gibt es kein Halten mehr.\\nEin verrücktes Programm, in einer verrückten Zeit: Nach diesem Programm sind auch\\nSie total verrückt: Verrückt nach Müller!\\n<br><br><br>\\n<b>Pressestimmen</b>\\n<br><br><i>\\n„Nichts und Niemand aus Politik, Boulevard und Gesellschaft ist vor seinem erfrischend\\nrespektlosen Mundwerk sicher, wenn er pointenreich auf Reise geht. Sage und\\nschreibe dreieinhalb Stunden (…) beherrscht der energiegeladene Komiker Bühne,\\nSaal und Publikum, das aus dem Lachen gar nicht mehr herauskommt.“ </i>Main-Post\\n\\n<br><br><i>\\n„Von den Bayern 1-Hörern wurde er 2011 auf Platz zwei der lustigsten Bayern gewählt.\\n(…), vor dem großen Karl Valentin.“ </i>Augsburger Allgemeine\\n\\n                            \",\n" +
        "  \"type\" : \"Kabarett\",\n" +
        "  \"subType\" : null,\n" +
        "  \"price\" : 30.6\n" +
        "}";
  }

  public static EO createMuellerEo() {
    EoRoot eo = ObjectProvider.createEoWithClasses(Event.class);
    return eo.map(getMueller());
  }

  public static Event createExampleEvent() {
    return (Event) createMuellerEo().get();
  }

  public static List<Event> createLU2205Json() {
    ObjectProvider.createEoWithClasses(List.class, Event.class);
    return new IOClasspathEOFlatList<Event>(ObjectProvider.CONFIG_MAPS, "LU2205.json", Event.class).read();
  }

  public static EO createLU2205JsonEO() {
    EoRoot eo = ObjectProvider.createEoWithClasses(List.class, Event.class);
    String events = new IOString("LU2205.json").read();
    eo.map(events);
    return eo;
  }

  public static EoRoot readEoXlsx() {
    return EventService.readEoXlsx(TEST_XLSX);
  }

  public static List<Event> createTest() {
    return  EventService.readXlsx(TEST_XLSX);
  }

  public static EoRoot createEoInMuenchen1() {
    return EventService.readEoXlsx(IN_MUENCHEN1);
  }
  public static EoRoot createEoInMuenchen2() {
    return EventService.readEoXlsx(IN_MUENCHEN2);
  }

  public static List<Event> createInMuenchen() {
    return  EventService.readXlsx(IN_MUENCHEN1);
  }

}
