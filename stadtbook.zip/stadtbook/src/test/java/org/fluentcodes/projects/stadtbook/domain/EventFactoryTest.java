package org.fluentcodes.projects.stadtbook.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;
import org.fluentcodes.projects.elasticobjects.EO;
import org.fluentcodes.projects.elasticobjects.EOInterfaceScalar;
import org.junit.jupiter.api.Test;

public class EventFactoryTest {
  @Test
  public void createEoTest() {
    EO eo = EventFactory.readEoXlsx();
    assertEquals(1, eo.size());

    assertEquals(Event.class, eo.getEo("0").getModelClass());
    EOInterfaceScalar firstEo = eo.getEo("0");
    assertEquals("Digitales Kinderangebot", firstEo.get("title"));
    assertFalse(firstEo.hasEo("artistTitle"));
  }

  @Test
  public void createTest() {
    List<Event> list = EventFactory.createTest();
    assertEquals(1, list.size());
    Event event = list.get(0);
    assertEquals(Event.class, event.getClass());
    assertEquals("Digitales Kinderangebot", event.getTitle());
    assertEquals("Digitales Kinderangebot", event.getArtistTitle());
  }

}
