package org.fluentcodes.projects.stadtbook.domain;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.junit.Test;

public class EventRepeatedTest {
  @Test
  public void setStartDate() {
    EoRoot root = ObjectProvider.createEoWithClasses(EventRepeated.class);
    root.set("1.1", "startDate");
    assertEquals(LocalDate.of(2022,1,1), root.get("startDate"));
  }
}
