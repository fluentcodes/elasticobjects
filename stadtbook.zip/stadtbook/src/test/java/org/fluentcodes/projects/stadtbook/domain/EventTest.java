package org.fluentcodes.projects.stadtbook.domain;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.List;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.models.FieldConfig;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.tools.io.IOString;
import org.junit.jupiter.api.Test;

public class EventTest {

  @Test
  public void exampleEventEo() {
    assertEquals("Michl Müller", EventFactory.createMuellerEo().get("artist"));
  }

  @Test
  public void mapListEvent() {
    EoRoot eo = ObjectProvider.createEoWithClasses(List.class, Event.class);
    String events = new IOString("LU2205.json").read();
    eo.map(events);
    List<Event> eventList = (List<Event>)eo.get();
    assertEquals("Michl Müller", eo.get("0/artist"));
    assertEquals("Michl Müller", eventList.get(0).getArtist());
  }

  @Test
  public void mapListEventDirect() {
    List<Event> eventList = EventFactory.createLU2205Json();
    assertEquals("Michl Müller", eventList.get(0).getArtist());
  }

  @Test
  public void localDateTime() {
    LocalDateTime localDateTime = LocalDateTime.parse("2022-03-01T00:00");
    assertEquals("2022-03-01T00:00", localDateTime.toString());
  }

  @Test
  public void checkFieldConfig_content() {
    FieldConfig fieldConfig = (FieldConfig)ObjectProvider.CONFIG_MAPS.find(FieldConfig.class, "content");
    assertEquals(Integer.valueOf(10000), fieldConfig.getProperties().getMax());
  }

  @Test
  public void mapEvent() {
    EoRoot eo = ObjectProvider.createEoWithClasses(Event.class);
    eo.map("{\n" +
        "  \"id\" : null,\n" +
        "  \"otherUrls\" : [ \"https://www.youtube.com/results?search_query=Iris+Berben\" ],\n" +
        "  \"url\" : \"https://www.lustspielhaus.de/kuenstler/programm/4901\",\n" +
        "  \"location\" : \"Lustspielhaus\",\n" +
        "  \"locationStreet\" : null,\n" +
        "  \"locationTown\" : null,\n" +
        "  \"locationPlz\" : null,\n" +
        "  \"startTime\" : \"2022-05-29T19:30:00\",\n" +
        "  \"artist\" : \"Iris Berben\",\n" +
        "  \"title\" : \"liest: das „Ukrainische Tagebuch“ von Oxana Matiychuk\",\n" +
        "  \"content\" : \"\\n                                Seit Beginn des Krieges berichtet Oxana Matiychuk für die „Süddeutsche Zeitung“  fast täglich aus der Ukraine. Die Leser des Feuilletons kennen sie als scharfsichtige und warmherzige Chronistin. Nun kommt sie nach München, um über ihr Land und von ihren Erfahrungen im Krieg zu berichten und Publikumsfragen zu beantworten, die Schauspielerin Iris Berben wird aus ihren Texten lesen. Durch die Veranstaltung führt Sonja Zekri, SZ-Kulturkorrespondentin in Berlin.\\n\\n                            \",\n" +
        "  \"type\" : \"Kabarett\",\n" +
        "  \"subType\" : null,\n" +
        "  \"price\" : 15.0\n" +
        "}");
      assertEquals("Iris Berben", eo.get("artist"));
  }

}
