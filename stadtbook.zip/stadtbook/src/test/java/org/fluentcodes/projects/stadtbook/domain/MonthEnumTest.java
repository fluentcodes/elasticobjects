package org.fluentcodes.projects.stadtbook.domain;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class MonthEnumTest {

  @Test
  public void testMai() {
    assertEquals("Mai", MonthEnum.getDefault("Mai"));
  }

  @Test
  public void testMaiInt() {
    assertEquals(5, MonthEnum.getInt("Mai"));
  }

  @Test
  public void testJuniInt() {
    assertEquals(6, MonthEnum.getInt("Juni"));
    assertEquals(6, MonthEnum.getInt("Jun"));
  }

  @Test
  public void testJuliInt() {
    assertEquals(7, MonthEnum.getInt("Juli"));
    assertEquals(7, MonthEnum.getInt("Jul"));
  }

  @Test
  public void testAugustInt() {
    assertEquals(8, MonthEnum.getInt("August"));
    assertEquals(8, MonthEnum.getInt("Aug"));
  }
}
