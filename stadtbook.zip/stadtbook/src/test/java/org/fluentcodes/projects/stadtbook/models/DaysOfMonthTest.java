package org.fluentcodes.projects.stadtbook.models;

import static org.junit.Assert.assertEquals;

import java.time.Month;
import org.junit.jupiter.api.Test;

public class DaysOfMonthTest {
  @Test
  public void testMay2022() {
    DaysOfMonth daysOfMonth = new DaysOfMonth(2022, Month.MAY);
    assertEquals(41, daysOfMonth.size());
  }
}
