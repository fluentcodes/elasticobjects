package org.fluentcodes.projects.stadtbook.parser;

import static org.junit.Assert.assertEquals;

import java.util.List;
import org.fluentcodes.projects.stadtbook.domain.EventParsed;
import org.junit.jupiter.api.Test;

public class ParserLangeNachtDerMusikTest {


  @Test
  public void parse() {
    List<EventParsed> events = new ParserLangeNachtDerMusik(true).parse("https://www.muenchner.de/musiknacht/bands");
    assertEquals(1, events.size());
  }

  @Test
  public void parseAll() {
    List<EventParsed> events = new ParserLangeNachtDerMusik().parse("https://www.muenchner.de/musiknacht/bands");
    for (EventParsed event:events){
      System.out.println(event.toString());
    }
  }
}
