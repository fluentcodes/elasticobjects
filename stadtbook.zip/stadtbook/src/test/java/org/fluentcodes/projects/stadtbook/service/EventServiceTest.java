package org.fluentcodes.projects.stadtbook.service;

import org.junit.jupiter.api.Test;

public class EventServiceTest {
  @Test
  public void readXlsx() throws Exception {
    EventService.readXlsx("test.xlsx");
  }
}
