package org.fluentcodes.projects.stadtbook.temp;

import static org.fluentcodes.projects.stadtbook.calls.CreateHtmlPageDayCall.DB_H2_FILE;
import static org.fluentcodes.projects.stadtbook.calls.EventCall.INPUT_DIR;
import static org.fluentcodes.projects.stadtbook.calls.EventDbFileInitIT.DB_MODELS_H2_FILE;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.fluentcodes.projects.elasticobjects.EoRoot;
import org.fluentcodes.projects.elasticobjects.calls.db.DbModelReadCall;
import org.fluentcodes.projects.elasticobjects.calls.db.DbSqlReadCall;
import org.fluentcodes.projects.elasticobjects.calls.xlsx.XlsxWriteCall;
import org.fluentcodes.projects.elasticobjects.testitems.ObjectProvider;
import org.fluentcodes.projects.stadtbook.domain.Event;
import org.fluentcodes.projects.stadtbook.domain.PostalAddress;
import org.junit.jupiter.api.Test;

public class TempQueryCreator {

  @Test
   public void readCalenderFromDb() {
    EoRoot eo = EoRoot.of(ObjectProvider.CONFIG_MAPS);
    DbSqlReadCall call = new DbSqlReadCall(DB_H2_FILE, "EventLocations");
    call.getListParams().setRowEnd(10000);
    call.setTargetPath("/(List)locations");
    call.execute(eo);
    List<Map<String, String>> locations = (List<Map<String, String>>)eo.get("locations");
    Map<String, Set<String>> locationMap = new TreeMap<>();
    Map<String, Set<String>> typeMap = new TreeMap<>();
    for (Map<String, String> entry: locations) {
      //System.out.println(entry);
      String location = entry.get("location");
      String type =entry.get("type");
      String upperLocation = location.replaceAll("[^\\w]", "")
          .toUpperCase(Locale.ROOT);
      if (!locationMap.containsKey(upperLocation)) {
        locationMap.put(upperLocation, new TreeSet<>());
      }
     locationMap.get(upperLocation).add(location);
      if (!typeMap.containsKey(upperLocation)) {
        typeMap.put(upperLocation, new TreeSet<>());
      }
      typeMap.get(upperLocation).add(type);
    }
    for (Map.Entry<String, Set<String>> entry: locationMap.entrySet()) {
      if (entry.getValue().size()>1) {
        System.out.println(entry.getKey() + entry.getValue());
      }
    }
    for (Map.Entry<String, Set<String>> entry: typeMap.entrySet()) {
      if (entry.getValue().size()>1) {
        System.out.println(entry.getKey() + entry.getValue());
      }
    }
  }

  @Test
  public void cleanupAllEvents() {
    EoRoot eo = ObjectProvider.createEo();
    DbSqlReadCall call = new DbSqlReadCall(DB_H2_FILE, "AllEvents");
    call.getListParams().setRowEnd(100000);
    call.setTargetPath("/(List,Event)events");
    call.execute(eo);
    List<Event> events = (List<Event>)eo.get("events");
    for (Event entry: events) {
      System.out.println(entry);
    }
  }
}
